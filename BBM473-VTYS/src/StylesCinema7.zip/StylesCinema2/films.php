<!DOCTYPE html>


<?php
    include "auth.class.php";
    $var = new auth();
?>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <title> Users - Forum </title>
    <link rel="stylesheet" href="assets/stylesheets/main.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400">
  
<style type="text/css" media="screen">

.tip {
  width: 0px;
  height: 0px;
  
  position: absolute;
  
  background: transparent;
  border: 10px solid #ccc;
}

.tip-right {
  top: 10px;
  right: -25px;
  border-top-color: transparent;
  border-right-color: transparent;
  border-bottom-color: transparent;  
}

.dialogbox .body {
  position: relative;
  
  
  max-width: 550px;
  height: auto;
  margin: 20px 10px;
  padding: 5px;
  background-color: #DADADA;
  border-radius: 3px;
  border: 5px solid #ccc;
}

.body .message {
  min-height: 40px;
  border-radius: 3px;
  font-family: Arial;
  font-size: 14px;
  line-height: 1.5;
  color: #797979;
}

select {
width:500px;

font: 300 16px/22px "Lato", "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
font-weight:normal;
background:#e6ffe6;
padding:10px;
border:1px solid
}
input[type=radio] {
    vertical-align: text-bottom;
margin-left:15px;
margin-top:10px
    
}
input[type=submit] {
   
padding:10px;
text-align:center;
font-size:18px;
background:linear-gradient(#cce6ff 5%,#fff0b3 100%);
/*border:2px solid #e5a900;*/
color:#001a4d;
font-weight:700;
cursor:pointer;
width:30%;
border-radius:5px
}
input[type=submit]:hover {
  
background:linear-gradient(#fff0b3 5%, #cce6ff 100%);
    color: #1ab2ff;
}







</style>
</head>
  <body>

    <!-- Header -->

    <header class="primary-header container group">

      <h1 class="logo">
        <a href="index.php">Share US <br> Forum </a>
      </h1>

       <h3 class="tagline" style="font-weight: normal;"> BBM Movie Archive </h3>

      <nav class="nav primary-nav">
        <ul>
          <li><a href="index.php">Home</a></li><!--
          --><li><a href="filmtypes/romantic.php">Romantic</a></li><!--
          --><li><a href="filmtypes/adventure.php">Adventure</a></li><!--
          --><li><a href="filmtypes/comedy.php">Comedy</a></li>
             <li><a href="filmtypes/drama.php">Drama</a></li>
             <li><a href="filmtypes/horror.php">Horror</a></li>
             <li><a href="filmtypes/action.php">Action</a></li>
             <li><a href="filmtypes/animated.php">Animated</a></li>
             <li><a href="filmtypes/animated.php">Science Fiction</a></li>
             <li><a href="filmtypes/animated.php">Historical movies</a></li>
             <li><a href="filmtypes/animated.php">Thriller</a></li>

<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

       
       
       
    </header>
    
    <!-- Lead -->

    <section class="row-alt">
      <div class="lead container">

       
          
          
          
          <?php
    
        $filmname=filter_input(INPUT_POST, 'filmname');      
        $filmtime=filter_input(INPUT_POST, 'filmtime');
        $filmtype1=filter_input(INPUT_POST, 'filmtype1');
        $filmtype2=filter_input(INPUT_POST, 'filmtype2');
        $filmtype3=filter_input(INPUT_POST, 'filmtype3');
        $imageinfo=filter_input(INPUT_POST, 'imageinfo');
                      
	?>
          
          
         <div class="lead container">           
                         
                 <div style= padding-bottom:5px > 
                     <h3> Click "addfilm" button for add a film to archieve. </h3>
                     <a href="addfilm.php"><input type="submit" name="submit1" value=" Add a film " /></a>  </div>
             <div></br></br><h3> Enter movie information to search for movies in our archive. </h3>
			 
			 
			<form action="" method="post" name="formf" enctype="multipart/form-data"> 
             
                 <input type="text" name="filmname" placeholder=" Searching Film Name" style='width:500px'/></div>
                 
              <div style= "padding-bottom:10px;padding-top: 10px" >     
                
                <select name="Types" >
                <option value="default"> Select a film type...</option>
                <option value="1">Romantic </option>
                <option value="2"> Adventure </option>
                <option value="3"> Comedy </option>
                <option value="4"> Drama </option>
                <option value="5"> Horror </option>
                <option value="6">Action </option>
                <option value="7"> Animated movies </option>
                <option value="8"> Science Fiction </option>
                <option value="9"> Historical movies </option>
                <option value="10"> Thriller </option>
                </select>
                </div>  
                 
   <div style= "padding-bottom:10px;" >
<select name="Years">
<option value="default"> Select a year  </option>
<option value="2017"> 2017 </option>
<option value="2016"> 2016 </option>
<option value="2015"> 2015 </option>
<option value="2014"> 2014 </option>
<option value="2013"> 2013 </option>
<option value="2012"> 2012 </option>
<option value="2011"> 2011 </option>
<option value="2010"> 2010 </option>
<option value="2009"> 2009 </option>
<option value="2008"> 2008 </option>
<option value="2007"> 2007 </option>
<option value="2006"> 2006 </option>
<option value="2005"> 2005 </option>
<option value="2004"> 2004 </option>
<option value="2003"> 2003 </option>
<option value="2002"> 2002 </option>
<option value="2001"> 2001 </option>
<option value="2000"> 2000 </option>
<option value="1999"> 1999 </option>
<option value="1998"> 1998 </option>
<option value="1997"> 1997 </option>
<option value="1996"> 1996 </option>
<option value="1995"> 1995 </option>
<option value="1994"> 1994 </option>
<option value="1993"> 1993 </option>
<option value="1992"> 1992 </option>
<option value="1991"> 1991 </option>
<option value="1990"> 1990 </option>
<option value="1989"> 1989 </option>
<option value="1988"> 1988 </option>
<option value="1987"> 1987 </option>
<option value="1986"> 1986 </option>
<option value="1985"> 1985 </option>
<option value="1984"> 1984 </option>
<option value="1983"> 1983 </option>
<option value="1982"> 1982 </option>
<option value="1981"> 1981 </option>
<option value="1980"> 1980 </option>
<option value="1979"> 1979 </option>
<option value="1978"> 1978 </option>
<option value="1997"> 1977 </option>
<option value="1976"> 1976 </option>
<option value="1975"> 1975 </option>



</select>
       </div>                          
        <div style= padding-bottom:5px >          
                   
        <select name="Vision">
        <option value="default"> Select a film info...</option>
        <option value="archieve"> From the archive </option>
        <option value="vision"> In the vision </option>
        <option value="coming"> Coming soon </option>
        </select>
        </div>
             
             
             
             
       <div style= padding-bottom:5px >               
                   
<input type="radio" name="time1" value="02:00"> More than 2 hours
    <div style= padding-bottom:5px >
<input type="radio" name="time2" value="01:00">Between 1 and 2 hours
    <div style= padding-bottom:5px >
<input type="radio" name="time3" value="00:30">Less than half an hour
    </div> <div style= padding-bottom:5px >
<input type="submit" name="submit" value="Get Selected Values" />

                        </div>
                    </div>
                        </div>
						
						
						</form>
                    </div>
<?php
    if(isset($_POST['submit'])){
		
        $filmname= filter_input(INPUT_POST, 'filmname', FILTER_SANITIZE_STRING);
        
        
        $selected_val= filter_input(INPUT_POST, 'Types', FILTER_SANITIZE_STRING);
        $selected_val2= filter_input(INPUT_POST, 'Years', FILTER_SANITIZE_STRING);
        $selected_val3= filter_input(INPUT_POST, 'Vision', FILTER_SANITIZE_STRING);
        if(isset($_POST['time1'])){
            
            $result = $var->searchFilm($filmname, $selected_val,$selected_val2, "02:00","16:00",$selected_val3);
           
            while ($row = $result->fetch_assoc()) {
                echo $row['Film_Name'];
            }
        
        }
    
        else if(isset($_POST['time2'])){
            
            $result = $var->searchFilm($filmname, $typeName, "01:00", "02:00",$selected_val3);
            while ($row = $result->fetch_assoc()) {
                echo $row['Film_Name'];
            }
        }
        else if(isset($_POST['time3'])){
            
            $result = $var->searchFilm($filmname, $typeName, "00:00", "00:30",$selected_val3);
            while ($row = $result->fetch_assoc()) {
                echo $row['Film_Name'];
            }
            
        }
        
        
        
    }
?>                 
            
         
      
      
      </div>
        
          
      
    </section>
    
      
  
  <div class="link">
                             <a href="reports/filmstoexcel2003.php"><input name="link1" value=" Reporting Excel " /></a>  
                             <a href="reports/filmstohtml.php"><input name="link2" value=" Reporting Html " /></a>
  </div>


    <!-- Footer -->

    <footer class="primary-footer container group">

      <small>&copy; Styles Films</small>

      <nav class="nav">
        <ul>
          <li><a href="index.php">Home</a></li>
         
          <li><a href="/films.php"> Films </a></li>
          <li><a href="/statistics.php"> Site Statistics </a></li>
	   <li><a href="/pages.php">Pages</a></li>
            <li><a href="/comments.php">Forum</a></li>
<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

    </footer>

  </body>
</html>

<?php
   
    if(isset($_POST['comment']))
        {
            $comment= filter_input(INPUT_POST, 'comment', FILTER_SANITIZE_STRING);
            
            
            if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);
                $var->addComment($username, $comment);             
            } else
            {
                $username = 'Guest';
                $var->addComment($username, $comment);              
                
            }
            
            header("Refresh: 0;");
        }
        
?>
