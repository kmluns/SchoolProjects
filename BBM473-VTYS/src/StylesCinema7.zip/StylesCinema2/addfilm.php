<!DOCTYPE html>


<?php
    include "auth.class.php";
    $var = new auth();
    if( !isset($_COOKIE["auth_session"]) )
    {  
        echo "You did not login!!!";
        header("Location: index.php"); /* Redirect browser */
        exit(); 
    }
	
?>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <title> Users - Forum </title>
    <link rel="stylesheet" href="assets/stylesheets/main.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400">
  
<style type="text/css" media="screen">

.tip {
  width: 0px;
  height: 0px;
  
  position: absolute;
  
  background: transparent;
  border: 10px solid #ccc;
}

.tip-right {
  top: 10px;
  right: -25px;
  border-top-color: transparent;
  border-right-color: transparent;
  border-bottom-color: transparent;  
}

.dialogbox .body {
  position: relative;
  
  
  max-width: 550px;
  height: auto;
  margin: 20px 10px;
  padding: 5px;
  background-color: #DADADA;
  border-radius: 3px;
  border: 5px solid #ccc;
}

.body .message {
  min-height: 40px;
  border-radius: 3px;
  font-family: Arial;
  font-size: 14px;
  line-height: 1.5;
  color: #797979;
}
</style>
</head>
  <body>

    <!-- Header -->

    <header class="primary-header container group">

      <h1 class="logo">
        <a href="index.php">Share US <br> Forum </a>
      </h1>

       <h3 class="tagline" style="font-weight: normal;"> BBM Movie Archive </h3>

      <nav class="nav primary-nav">
        <ul>
          <li><a href="index.php">Home</a></li>
<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

    </header>

    <!-- Lead -->

    <section class="row-alt">
      <div class="lead container">

          <form action="" method="post" name="formf" enctype="multipart/form-data">
			
                        <br>Film Title </br><input type="text" name="filmtitle" placeholder=" Film Title" required style='width:300px'/>
                        <br>Film Name </br><input type="text" name="filmname" placeholder=" Film Name" required style='width:300px'/>
			<br>Time( x:x ) </br> <input type="text" name="filmtime" placeholder=" Film Time ( x:x )" required style='width:300px'/>
                        <br>Film Make Year </br> <input type="text" name="filmyear" placeholder=" Film Make Year " required style='width:300px'/>
                        <br>Company Name</br> <input type="text" name="companyname" placeholder=" Company Name " required style='width:300px'/>
                        <br/>Types <br/><label><input type="checkbox" name="filmtype[]" value="1"/> Romantıic</label>
                        <label><input type="checkbox" name="filmtype[]" value="2"/> Adventure</label>
                        <label><input type="checkbox" name="filmtype[]" value="3"/> Comedy</label>
                        <label><input type="checkbox" name="filmtype[]" value="4"/> Drama</label>
                        <label><input type="checkbox" name="filmtype[]" value="5"/> Horror</label>
                        <label><input type="checkbox" name="filmtype[]" value="6"/> Action</label>
                        <label><input type="checkbox" name="filmtype[]" value="7"/> Animated</label>
						<br>Director SSN </br> <input type="text" name="directorssn" placeholder=" Director SSN" required style='width:300px'/>
                        <br>Film Information </br><textarea name="filminfo" placeholder=" Film Information" required rows="5" cols="40"></textarea>
                        <br>Image :  <input type="file" name="image" required/>
                        <br><input  type="submit" name="send" value=" Save " /> </br>      
                </form>
          
          
          
          
          
          
          
          
<?php
    
        
        
       
        
		if(isset($_POST['filmname'])){
                    $filmname=filter_input(INPUT_POST, 'filmname');
                    $filmtitle=filter_input(INPUT_POST, 'filmtitle');
                    $filmtime=filter_input(INPUT_POST, 'filmtime');
                    $filminfo=filter_input(INPUT_POST, 'filminfo');
                    $filmtype1=filter_input(INPUT_POST, 'filmtype1');
                    $filmtype2=filter_input(INPUT_POST, 'filmtype2');
                    $filmtype3=filter_input(INPUT_POST, 'filmtype3');
                    $imageinfo=filter_input(INPUT_POST, 'imageinfo');
                    $filmyear=filter_input(INPUT_POST, 'filmyear');
                    $companyname=filter_input(INPUT_POST, 'companyname');
					$directorssn=filter_input(INPUT_POST, 'directorssn');
                    $filmtype= $_POST['filmtype'];
	
					if($_FILES["image"]["size"]<1024*1024){
						if($_FILES["image"]["type"]==="image/jpeg"||"image/jpg" || "image/png"){
							$imageinfo=filter_input(INPUT_POST, 'imageinfo');
							$file_name=$_FILES["image"]["name"];
							$generate=array("a","b","c","f");
							$random_number=rand(1,10000);					
							$format=substr(($file_name), -4,4);
							$imagenewname="assets/images/banner/".$generate[rand(0,4)].$random_number.$format;
							if(move_uploaded_file($_FILES["image"]["tmp_name"],$imagenewname)){
								echo "Image is uploaded succesfully!!!";                    
								$Session= $var->sessioninfo($_COOKIE["auth_session"]);
								$username = ($Session["username"]);
                                
								
								$var->insertFilm($filmname, $filmtitle, $filmtime, $imagenewname, $filminfo, $filmtype,$filmyear, $directorssn,$companyname, $username);
								
								
								echo"Image inserted to the DB";
								
							}else{
								echo "File is not uploaded";
							}
							
						}else{
							echo "file format not correct";
						}
						
					}else{
						echo "File size can not be greater than 1 MB!!!";
					}
                
                    
		}
	
?>
          
          
          
          
          
      </div>
    </section>
    
    
    
                
                
             

                
        
        


    <!-- Footer -->

    <footer class="primary-footer container group">

      <small>&copy; Styles Conference</small>

      <nav class="nav">
        <ul>
            <li><a href="index.php">Home</a></li>
<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

    </footer>

  </body>
</html>

