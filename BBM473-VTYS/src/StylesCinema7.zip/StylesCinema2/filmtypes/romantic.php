<!DOCTYPE html>


<?php
    include "../auth.class.php";
    $var = new auth();
?>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <title> Users - Forum </title>
    <link rel="stylesheet" href="../assets/stylesheets/main.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400">
  
<style type="text/css" media="screen">

.tip {
  width: 0px;
  height: 0px;
  
  position: absolute;
  
  background: transparent;
  border: 10px solid #ccc;
}

.tip-right {
  top: 10px;
  right: -25px;
  border-top-color: transparent;
  border-right-color: transparent;
  border-bottom-color: transparent;  
}

.dialogbox .body {
  position: relative;
  
  
  max-width: 550px;
  height: auto;
  margin: 20px 10px;
  padding: 5px;
  background-color: #DADADA;
  border-radius: 3px;
  border: 5px solid #ccc;
}

.body .message {
  min-height: 40px;
  border-radius: 3px;
  font-family: Arial;
  font-size: 14px;
  line-height: 1.5;
  color: #797979;
}

select {
width:500px;

font: 300 16px/22px "Lato", "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
font-weight:normal;
background:#e6ffe6;
padding:10px;
border:1px solid
}
input[type=radio] {
    vertical-align: text-bottom;
margin-left:15px;
margin-top:10px
    
}
input[type=submit] {
   
padding:10px;
text-align:center;
font-size:18px;
background:linear-gradient(#cce6ff 5%,#fff0b3 100%);
/*border:2px solid #e5a900;*/
color:#001a4d;
font-weight:700;
cursor:pointer;
width:30%;
border-radius:5px
}
input[type=submit]:hover {
  
background:linear-gradient(#fff0b3 5%, #cce6ff 100%);
    color: #1ab2ff;
}


 .rating {
          overflow: hidden;
          display: inline-block;
      }
      .rating-input {
          position: absolute;
          left: 0;
          top: -50px;
      }
      .rating-star {        
          display: block;
          float: right;        
          width: 16px;
          height: 16px;
          background: url('http://kubyshkin.ru/samples/star-rating/star.png') 0 -16px;
      }
      .rating-star:hover,
      .rating-star:hover ~ .rating-star,
      .rating-input:checked ~ .rating-star {
          background-position: 0 0;
      }

/* Just for the demo */
body {
    margin: 20px;
}







</style>
</head>
  <body>

    <!-- Header -->

    <header class="primary-header container group">

      <h1 class="logo">
        <a href="../index.php">Share US <br> Forum </a>
      </h1>

       <h3 class="tagline" style="font-weight: normal;"> BBM Movie Archive </h3>

      <nav class="nav primary-nav">
        <ul>
          <li><a href="../index.php">Home</a></li>
          <li><a href="romantic.php">Romantic</a></li><!--
          --><li><a href="adventure.php">Adventure</a></li><!--
          --><li><a href="comedy.php">Comedy</a></li>
             <li><a href="drama.php">Drama</a></li>
             <li><a href="horror.php">Horror</a></li>
             <li><a href="action.php">Action</a></li>
             <li><a href="animated.php">Animated</a></li>
             <li><a href="ScienceF.php">Science Fiction</a></li>
             <li><a href="historical.php">Historical movies</a></li>
             <li><a href="thriller.php">Thriller</a></li>
             
             

<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

       
       
       
    </header>
    
    <!-- Lead -->

    <section class="row-alt">
      <div class="lead container">
	  
<?php
    
    $result = $var->printFilms("1");
	$x=0;
    while ($row = $result->fetch_assoc()) {
		
?>		
		
	<div class="films">	
		<br/> <p>
		
<?php
        echo 'Film Name : '.$row['Film_Name'];




?>


		</p><img src = "
		
<?php		
		
		echo $row['Film_Banner'];

?>
		" alt="
<?php		
		
		echo $row['Film_Title'];
		
?>

		" width="250" height="300"> <br/> <p>
		
<?php

	echo 'Information : '  .$row['Film_Information'];

?>		
	<br/>
	<span class="rating">
        <input type="radio" class="rating-input" id="rating-input- <?php echo $x;?> -5" name="rating-input-<?php echo $x;?>" value = "<?php echo $row['Film_ID'];?>" onclick="starsfive('<?php echo $row['Film_Name'];?>','<?php echo $x;?>');">
        <label for="rating-input-<?php echo $x;?>-5" class="rating-star"></label>
        <input type="radio" class="rating-input" id="rating-input-<?php echo $x;?>-4" name="rating-input-<?php echo $x;?>" value = "<?php echo $row['Film_ID'];?>" onclick="starsfour('<?php echo $row['Film_Name'];?> ',' <?php echo $x;?>');">
        <label for="rating-input-<?php echo $x;?>-4" class="rating-star"></label>
        <input type="radio" class="rating-input" id="rating-input-<?php echo $x;?>-3" name="rating-input-<?php echo $x;?>" value = "<?php echo $row['Film_ID'];?>" onclick="starsthree('<?php echo $row['Film_Name'];?>','<?php echo $x;?>');">
        <label for="rating-input-<?php echo $x;?>-3" class="rating-star"></label>
        <input type="radio" class="rating-input" id="rating-input-<?php echo $x;?>-2" name="rating-input-<?php echo $x;?>" value = "<?php echo $row['Film_ID'];?>" onclick="starstwo('<?php echo $row['Film_Name'];?>','<?php echo $x;?>');">
        <label for="rating-input-<?php echo $x;?>-2" class="rating-star"></label>
        <input type="radio" class="rating-input" id="rating-input-<?php echo $x;?>-1" name="rating-input-<?php echo $x;?>" value = "<?php echo $row['Film_ID'];?>" onclick="starsone('<?php echo $row['Film_Name'];?>','<?php echo $x;?>');">
        <label for="rating-input-<?php echo $x;?>-1" class="rating-star"></label>
    </span>
		
		
		<form action="" method="post" name="formf" id="<?php echo $row['Film_ID'];?>"" enctype="multipart/form-data">
  Comments: <br/><textarea name="comments" id="comments<?php echo $row['Film_ID'];?>" cols="25" rows="3" ></textarea>
	<input type="hidden" name="filmid" value="<?php echo $row['Film_ID'];?>">
<input type="hidden" name="filmname" value="<?php echo $row['Film_Name'];?>">	
  <br/><br/><input type="submit" id="<?php echo $row['Film_ID'];?>" name="buttonsubmit" value="Submit Comment" style="padding-top:10px;"/>
</form>
		
		
		
		
		
		
		
		
		</div>
<?php		
     $x = $x + 1;
    }

?>

<?php

	if(isset($_POST['buttonsubmit'])){
		
        $filmid=$_POST['filmid'];
		$comment=$_POST['comments'];
		$filmname=$_POST['filmname'];	
		$var->insertCommentFilm($comment,$filmid,$filmname,$username);		
	}
?>






<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
	<script>
        function starsfive(filmname,x) {
			for (i = 0; i < document.getElementsByName('rating-input-'+x).length; i++) {
                if(document.getElementsByName('rating-input-'+x)[i].checked == true) {
                    var filmid = document.getElementsByName('rating-input-'+x)[i].value;
                    break;
                }
			}
			$.post('', {variable1: filmid,variable2: filmname,star:"5" }   );
			
		}
		
		 function starsfour(filmname,x) {
			for (i = 0; i < document.getElementsByName('rating-input-'+x).length; i++) {
                if(document.getElementsByName('rating-input-'+x)[i].checked == true) {
                    var filmid = document.getElementsByName('rating-input-'+x)[i].value;
                    break;
                }
			}
			
			$.post('', {variable1: filmid,variable2: filmname,star:"4"});
		}
		
		 function starsthree(filmname,x) {
			for (i = 0; i < document.getElementsByName('rating-input-'+x).length; i++) {
                if(document.getElementsByName('rating-input-'+x)[i].checked == true) {
                    var filmid = document.getElementsByName('rating-input-'+x)[i].value;
                    break;
                }
			}
			
			$.post('', {variable1: filmid,variable2: filmname,star:"3"});
		}
		
		 function starstwo(filmname,x) {
			for (i = 0; i < document.getElementsByName('rating-input-'+x).length; i++) {
                if(document.getElementsByName('rating-input-'+x)[i].checked == true) {
                    var filmid = document.getElementsByName('rating-input-'+x)[i].value;
                    break;
                }
			}
			
			$.post('', {variable1: filmid,variable2: filmname,star:"2"});
		}
		
		 function starsone(filmname,x) {
			for (i = 0; i < document.getElementsByName('rating-input-'+x).length; i++) {
                if(document.getElementsByName('rating-input-'+x)[i].checked == true) {
                    var filmid = document.getElementsByName('rating-input-'+x)[i].value;
                    break;
                }
			}
			
			$.post('', {variable1: filmid,variable2: filmname,star:"1"});
		}
		
		
	</script>
 <?php
 
	if(isset($_POST['variable1'])){
                    
        $filmid=$_POST['variable1'];
		$filmname=$_POST['variable2'];
		$star=$_POST['star'];
        $var->rateFilm($filmid,$filmname,$star,$username);	             
	}


?> 
          
          </div>
        
          
      
    </section>
	
	

    

    <!-- Footer -->

    <footer class="primary-footer container group">

      <small>&copy; Styles Conference</small>

      <nav class="nav">
        <ul>
           <li><a href="../index.php">Home</a></li>
          <li><a href="../films.php"> Films </a></li>
          <li><a href="../statistics.php"> Site Statistics </a></li>
	   <li><a href="../pages.php">Pages</a></li>
            <li><a href="../comments.php">Forum</a></li>
<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

    </footer>

  </body>
</html>
