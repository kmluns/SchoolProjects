<?php
class auth
{  
	public $mysqli;
	public $errormsg;
	public $successmsg;
	
	function __construct()
	{
            include("config.php");
                
            $this->mysqli = new mysqli($db['host'], $db['user'], $db['pass'], $db['name']); 
            unset($db['pass']); // $mysqli is public, remove password for security
	}
		
	    
        function showLog($action){
            include("config.php");
            include("lang.php");
			
            try{    
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("SELECT L.username, L.date, L.additionalinfo FROM activitylog L WHERE L.action = ? order by L.date DESC LIMIT 10 ");
				$query->bind_param("s", $action);
				$query->execute();
				$result = $query->get_result();
				$query->close();
				$this->mysqli->autocommit(True);
				return $result; 
            }catch(Exception $e){
				$this->mysqli->rollback();	
            }
        }
		
		
		
		
		
		function printCommentFilms($filmid)
        {
            include("config.php");
			
            try{    
			
				$filmid = intval($filmid);
			
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("SELECT TC.Comment_Text, TC.Comment_Like , TC.date FROM tcomment TC JOIN rcomment RT NATURAL JOIN cinema_films F WHERE RT.Comment_ID = TC.Comment_ID AND F.Film_ID = RT.Film_ID AND F.Film_ID = ?  order by TC.date DESC ");              
				$query->bind_param("i", $filmid);
				$query->execute();
				$result = $query->get_result();
				$query->close();
				$this->mysqli->autocommit(True);
				return $result; 
			}catch(Exception $e){
				$this->mysqli->rollback();	
            }
        }
		
		
		 function insertCommentFilm($comment,$filmid,$filmname,$username){
			include("config.php");
                
            try{ 
                date_default_timezone_set('Europe/Istanbul');
				$date= date('Y.m.d H:i:s');
				
				$filmid = intval($filmid);
				
				
                $this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("INSERT INTO `tcomment`(`Comment_Text`,`date`) VALUES (?,?)");
				$query->bind_param("ss", $comment,$date);
				$query->execute();
				$query->close();
			
			
				$query2 = $this->mysqli->prepare("SELECT Comment_ID FROM tcomment WHERE Comment_Text=?");
                $query2->bind_param("s", $comment);
                $query2->bind_result($commentid);
                $query2->execute();
                $query2->store_result();
                $count = $query2->num_rows;
                $query2->fetch();
                $query2->close();
				
				
				$query3 = $this->mysqli->prepare("INSERT INTO `rcomment`(`Comment_ID`, `Film_ID`) VALUES (?,?)");
				$query3->bind_param("ii", $commentid,$filmid);
				$query3->execute();
				$query3->close();
						
						
				$this->LogActivity($username, "Comment", "{$comment} have been inserted by {$username} on {$filmname} film.");
				$this->mysqli->autocommit(True);
            }catch(Exception $e){
				echo 'hata çıkyır';
                $this->mysqli->rollback();	
		}       
	}
		
		
		
		
		
		
		
		
		function adminControl($username){
			
			try{    
                $this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("SELECT admin FROM users WHERE username=?");
                $query->bind_param("s", $username);
                $query->bind_result($admin);
                $query->execute();
                $query->store_result();
                $count = $query->num_rows;
                $query->fetch();
                $query->close();
                $this->mysqli->autocommit(True);				
				return $admin;
            }catch(Exception $e){
                $this->mysqli->rollback();
            }
		}
		
		function rateActor($personid,$personname,$rateid,$username){
			include("lang.php");
			
            try{
				$personid = intval($personid);
				$rateid = intval($rateid);
				
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("UPDATE `film_person` SET `Performor_Famous` = `Performor_Famous` + ? WHERE `Person_ID` = ?");
				$query->bind_param("ii",$rateid,$personid);
				$query->execute();
				$query->close();
		
                $this->LogActivity($username, "Rate", "{$personname} have been rated by {$username} with {$rateid} stars");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                echo "hata var";
				$this->mysqli->rollback();	
            }	
		}
		
		
		function rateFilm($filmid,$filmname,$rateid,$username){
			include("lang.php");
			
            try{
				$filmid = intval($filmid);
				$rateid = intval($rateid);
				
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("INSERT INTO `rating` (`Rate_ID`, `Film_ID` ) VALUES (?, ?)");
				$query->bind_param("ii",$rateid,$filmid);
				$query->execute();
				$query->close();
		
                $this->LogActivity($username, "Rate", "{$filmname} have been rated by {$username} with {$rateid} stars");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                echo "hata var";
				$this->mysqli->rollback();	
            }	
		}
		
		
		
		function deleteActAll(){
			include("config.php");
			
			try{ 
				$this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("DELETE FROM act WHERE 1");
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Act have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }
				
		}
		
		function deleteAct($PersonID, $FilmID){
			include("config.php");
				
			try{    
                $this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("DELETE FROM act WHERE Person_ID=? AND Film_ID= ?");
                $query->bind_param("ss", $PersonID, $FilmID);
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Act have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                 $this->mysqli->rollback();
            }		
		}
		
		function deleteLogAll(){
			include("config.php");
			
			try{ 
				$this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("DELETE FROM activitylog WHERE 1");
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Log have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		
		function deleteLogUsername($username){
			include("config.php");
				
			try{    
                $this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("DELETE FROM activitylog WHERE username=? ");
                $query->bind_param("s", $username);
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Log have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                 $this->mysqli->rollback();
            }		
		}
		
		function deleteFilmsAll(){
			include("config.php");
			
			try{ 
				$this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("DELETE FROM cinema_films WHERE 1");
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Films have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function deleteFilmName($filmname){
			include("config.php");
				
			try{    
                $this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("DELETE FROM cinema_films WHERE Film_Name=? ");
                $query->bind_param("s", $filmname);
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Films have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                 $this->mysqli->rollback();
            }		
		}
		
		
		function deleteCommentsAll(){
			include("config.php");
			
			try{ 
				$this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("DELETE FROM comments WHERE 1");
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Comments have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function deleteCommentUsername($username){
			include("config.php");
				
			try{    
                $this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("DELETE FROM comments WHERE username=? ");
                $query->bind_param("s", $username);
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Comments have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                 $this->mysqli->rollback();
            }		
		}
		
		function deletePersonAll(){
			include("config.php");
			
			try{ 
				$this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("DELETE FROM film_person WHERE 1");
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Persons have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function deletePersonName($personname){
			include("config.php");
				
			try{    
                $this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("DELETE FROM film_person WHERE Person_Name=? ");
                $query->bind_param("s", $personname);
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Person have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                 $this->mysqli->rollback();
            }		
		}
		
		function deletePersonCrewName($personname){
			include("config.php");
				
			try{    
                $this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("DELETE FROM film_person WHERE Person_Name=? AND Crew = true ");
                $query->bind_param("s", $personname);
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Crew have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                 $this->mysqli->rollback();
            }		
		}
		
		function deleteFilmTypeAll(){
			include("config.php");
			
			try{ 
				$this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("DELETE FROM film_type WHERE 1");
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Film Types have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function deleteGuestAll(){
			include("config.php");
			
			try{ 
				$this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("DELETE FROM guest WHERE 1");
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Guests have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function deleteGuestID($guestid){
			include("config.php");
				
			try{    
                $this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("DELETE FROM guest WHERE Guest_ID = ? ");
                $query->bind_param("s", $guestid);
                $query->execute();
                $query->close();
                $this->mysqli->autocommit(True);
				$this->LogActivity($username, "DELETE", "Guests have been deleted");
            }catch(Exception $e){
                 $this->mysqli->rollback();
            }		
		}
		
		function deleteMakeAll(){
			include("config.php");
			
			try{ 
				$this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("DELETE FROM make WHERE 1");
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Make have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function deleteMakeFromDate($makedate){
			include("config.php");
				
			try{    
                $this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("DELETE FROM make WHERE Make_Date < ? ");
                $query->bind_param("s", $makedate);
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Make have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                 $this->mysqli->rollback();
            }		
		}
		
		function deleteManageAll(){
			include("config.php");
			
			try{ 
				$this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("DELETE FROM manage WHERE 1");
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Manage have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function deleteManageIDs($PersonID,$FilmID){
			include("config.php");
				
			try{    
                $this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("DELETE FROM make WHERE Person_ID = ? AND Film_ID = ? ");
                $query->bind_param("ss", $PersonID,$FilmID);
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Manage have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                 $this->mysqli->rollback();
            }		
		}
		
		function deleteCompanyAll(){
			include("config.php");
			
			try{ 
				$this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("DELETE FROM producer_company WHERE 1");
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Company have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function deleteCompanyName($companyname){
			include("config.php");
				
			try{    
                $this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("DELETE FROM producer_company WHERE Company_Name = ? ");
                $query->bind_param("s", $companyname);
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Company have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                 $this->mysqli->rollback();
            }		
		}
		
		function deleteRateAll(){
			include("config.php");
			
			try{ 
				$this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("DELETE FROM rate WHERE 1");
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Company have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function deleteRatingAll(){
			include("config.php");
			
			try{ 
				$this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("DELETE FROM rating WHERE 1");
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Rating have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function deleteRatingFilm($filmname){
			include("config.php");
				
			try{    
                $this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("DELETE FROM producer_company C WHERE IN ( SELECT F.Film_ID FROM cinema_films F WHERE Film_Name = ?) ");
                $query->bind_param("s", $filmname);
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Rating have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                 $this->mysqli->rollback();
            }		
		}
		
		
		function deleteRCommentAll(){
			include("config.php");
			
			try{ 
				$this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("DELETE FROM rcomment WHERE 1");
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "RComment have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function deleteSessionAll(){
			include("config.php");
			
			try{ 
				$this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("DELETE FROM sessions WHERE 1");
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Sessions have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function deleteTCommentAll(){
			include("config.php");
			
			try{ 
				$this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("DELETE FROM tcomment WHERE 1");
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Table Comments have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function deleteTypingAll(){
			include("config.php");
			
			try{ 
				$this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("DELETE FROM typing WHERE 1");
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Typing have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function deleteWorkFilmAll(){
			include("config.php");
			
			try{ 
				$this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("DELETE FROM work_film WHERE 1");
                $query->execute();
                $query->close();
				$this->LogActivity($username, "DELETE", "Work have been deleted");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		function updateLog($newaction,$logid,$username){
			include("config.php");	
			
			try{    
                $this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("UPDATE activitylog SET action=? WHERE username=? AND id =? ");
                $query->bind_param("sss", $newaction, $username,$logid);
                $query->execute();
                $query->close();
				$this->LogActivity($username, "UPDATE", "Log have been updated by {$username}");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }		
		}
			
		function updateFilm ( $newTitle , $filmname ) {
			include("config.php");	
			
			try{    
                $this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("UPDATE cinema_films SET Film_Title=? WHERE Film_Name=?");
                $query->bind_param("ss", $newTitle, $filmname);
                $query->execute();
                $query->close();
				$this->LogActivity($username, "UPDATE", "Film have been updated");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function updateComments($newcomment,$searchkey,$username){
			include("config.php");	
			
			try{    
                $this->mysqli->autocommit(False);
				$key = '%' .$searchkey. '%';
                $query = $this->mysqli->prepare("UPDATE comments SET comment=? WHERE username=? comment LIKE ? ");
                $query->bind_param("sss", $newcomment, $username,$key);
                $query->execute();
                $query->close();
				$this->LogActivity($username, "UPDATE", "Forum comment have been updated by {$username}");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }		
		}
		
		
		function updatePerson($newname,$personname,$personid){
			include("config.php");	
			
			try{    
                $this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("UPDATE film_person SET Person_Name=? WHERE Person_Name=? AND Person_ID");
                $query->bind_param("sss", $newname, $personname,$personid);
                $query->execute();
                $query->close();
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }			
		}
		
		
		function updateGuestID($newid,$guestid){
			include("config.php");	
			
			try{    
                $this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("UPDATE guest SET Guest_ID=? WHERE Guest_ID=?");
                $query->bind_param("ss", $newname, $personname);
                $query->execute();
                $query->close();
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function updateMake($newdate,$filmname,$companyid){
			include("config.php");	
			
			try{    
                $this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("UPDATE make M SET M.Make_Date=? WHERE M.Film_ID IN ( SELECT F.Film_ID FROM cinema_films WHERE F.Film_Name = ? ) AND M.Company_ID =? ");
                $query->bind_param("sss", $newdate, $filmname,$companyid);
                $query->execute();
                $query->close();
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		
		function updateManage($newpersonid,$filmname,$personid){
			include("config.php");	
			
			try{    
                $this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("UPDATE manage M SET M.Person_ID=? WHERE M.Film_ID IN ( SELECT F.Film_ID FROM cinema_films WHERE F.Film_Name = ? )  AND M.Person_ID =?");
                $query->bind_param("sss", $newpersonid, $filmname,$personid);
                $query->execute();
                $query->close();
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function updateCompany($newdate,$companyname){
			include("config.php");	
			
			try{    
                $this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("UPDATE producer_company  SET Company_Establishment=? WHERE Company_Name = ?  ");
                $query->bind_param("ss", $newdate, $companyname);
                $query->execute();
                $query->close();
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function updateRate($newsum,$rateid){
			include("config.php");	
			
			try{    
                $this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("UPDATE rate  SET Rate_Sum=? WHERE Rate_ID = ?  ");
                $query->bind_param("ss", $newsum, $rateid);
                $query->execute();
                $query->close();
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function updateTComment($newcomment,$commentid){
			include("config.php");	
			
			try{    
                $this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("UPDATE tcomment  SET Comment_Text=? WHERE Comment_ID = ?  ");
                $query->bind_param("ss", $newcomment, $commentid);
                $query->execute();
                $query->close();
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		function updateWorkFilm($newPersonID,$filmname,$personid){
			include("config.php");	
			
			try{    
                $this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("UPDATE work_film W SET W.Person_ID=? WHERE W.Film_ID IN ( SELECT F.Film_ID FROM cinema_films WHERE F.Film_Name = ? ) AND W.Person_ID =? ");
                $query->bind_param("sss", $newPersonID, $filmname,$personid);
                $query->execute();
                $query->close();
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                $this->mysqli->rollback();
            }	
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		function insertCompany($company_name,$company_establishment,$username)
        {
            include("config.php");
            include("lang.php");
			
            try{
                
		$this->mysqli->autocommit(False);
		$query = $this->mysqli->prepare("INSERT INTO `Producer_Company` (`Company_Name` ,`Company_Establishment` ) VALUES (?, ?, ?)");
		$query->bind_param("sss",$company_name,$company_establishment);
		$query->execute();
		$query->close();
		
                $this->LogActivity($username, "Insert", "{$company_name} company have been inserted by {$username}");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                echo "hat var";
				$this->mysqli->rollback();	
            }
      
        }
		
		function insertCrew($personssn,$person_name,$person_sex,$username)
        {
            include("config.php");
            include("lang.php");
			
            try{
                $personssn = intval($personssn);
                
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("INSERT INTO `film_person`(`Person_ID`, `Person_Name`, `Person_Sex`,`Crew`) VALUES (?,?, ?, True )");
				$query->bind_param("iss", $personssn,$person_name,$person_sex);
				$query->execute();
				$query->close();
		
                $this->LogActivity($username, "Insert", "{$person_name} crew have been inserted by {$username}");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                echo "hat var";
				$this->mysqli->rollback();	
            }
      
        }
		
		function insertPerformer($personssn,$person_name,$person_sex,$performer_famous,$performer_startyear,$username)
        {
            include("config.php");
            include("lang.php");
			
            try{
                $personssn = intval($personssn);
                $performer_startyear = intval($performer_startyear);
                
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("INSERT INTO `film_person`(`Person_ID`, `Person_Name`, `Person_Sex`,`Performer_Famous`,`Performer_Startyear`,`Crew`) VALUES (?,?, ?, ?,?, False )");
				$query->bind_param("issis", $personssn,$person_name,$person_sex,$performer_startyear,$performer_startyear);
				$query->execute();
				$query->close();
		
                $this->LogActivity($username, "Insert", "{$person_name} performer have been inserted by {$username}");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                echo "hat var";
				$this->mysqli->rollback();	
            }
      
        }
        
        function insertDirector($personssn,$person_name,$person_sex,$director_famous,$username)
        {
            include("config.php");
            include("lang.php");
			
            try{
                $personssn = intval($personssn);
                $director_famous = intval($director_famous);
                
		$this->mysqli->autocommit(False);
		$query = $this->mysqli->prepare("INSERT INTO `film_person`(`Person_ID`, `Person_Name`, `Person_Sex`,`Director_Famous`,`Crew`) VALUES (?,?, ?, ?, False )");
		$query->bind_param("issi", $personssn,$person_name,$person_sex,$director_famous);
		$query->execute();
		$query->close();
		
                $this->LogActivity($username, "Insert", "{$person_name} director have been inserted by {$username}");
                $this->mysqli->autocommit(True);
            }catch(Exception $e){
                echo "hat var";
		$this->mysqli->rollback();	
            }
      
        }
        
       
        
        function searchFilm($name = '',$typeName = '',$makeyear,$filmDuration1 = '0:0',$filmDuration2 ='16:00',$vision ='archive')
        {
            
            include("config.php");
            include("lang.php");
            $typeName = intval($typeName);
            $likeparam = '%' . $name. '%';
		if($vision =='archieve'){
                    try{    
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("SELECT  F.`Film_Name` FROM `cinema_films` F  JOIN `typing` T NATURAL JOIN `Make` M "
                                        . "WHERE M.`Make_Date` = ? AND  "
                                        ." T.`Type_ID`= ? AND  F.`Film_Duration` > ?  AND "
                                        . "F.`Film_Duration` < ?  AND F.`Film_ID` = T.`Film_ID` AND F.`Film_Name` LIKE ? ");
                                
				$query->bind_param("sisss",$makeyear,  $typeName, $filmDuration1,$filmDuration2,$likeparam);				
				$query->execute();
				$result = $query->get_result();
				$query->close();
				$this->mysqli->autocommit(True);
				return $result; 
			}catch(Exception $e){
				$this->mysqli->rollback();	
			}
                }else if ($vision == "vision"){
                     try{    
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("SELECT  F.`Film_Name` FROM `cinema_films` F   JOIN `typing` T  NATURAL JOIN `Make` M "
                                        . "WHERE M.`Make_Date` = ? AND  "
                                        ." T.`Type_ID`= ? AND  F.`Film_Duration` > ? AND F.`Showing` = true  AND "
                                        . "F.`Film_Duration` < ? AND F.`Film_Name` like ? AND F.`Film_ID` = T.`Film_ID`");
                                $query->bind_param("sisss",$makeyear,  $typeName, $filmDuration1,$filmDuration2,$likeparam);				
				$query->execute();
				$result = $query->get_result();
				$query->close();
				$this->mysqli->autocommit(True);
				return $result; 
			}catch(Exception $e){
				$this->mysqli->rollback();	
			}
                }else if ($vision == "coming"){
                     try{    
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("SELECT  F.`Film_Name` FROM `cinema_films` F   JOIN `typing` T  NATURAL JOIN `Make` M "
                                        . "WHERE M.`Make_Date` = ? AND  "
                                        ." T.`Type_ID`= ? AND  F.`Film_Duration` > ? AND F.`ComingSoon` = true  AND "
                                        . "F.`Film_Duration` < ? AND F.`Film_Name` like ? AND F.`Film_ID` = T.`Film_ID`");
                                $query->bind_param("sisss",$makeyear,  $typeName, $filmDuration1,$filmDuration2,$likeparam);				
				$query->execute();
				$result = $query->get_result();
				$query->close();
				$this->mysqli->autocommit(True);
				return $result; 
			}catch(Exception $e){
				$this->mysqli->rollback();	
			}
                }
			
        }
        
        function addComment($username,$comment)
        {
            date_default_timezone_set('Europe/Istanbul');
            $date= date('Y.m.d H:i:s');
            include("config.php");
            include("lang.php");
			
            try{		
		$this->mysqli->autocommit(False);
		$query = $this->mysqli->prepare("INSERT INTO comments (username, comment, date) VALUES (?, ?, ?)");
		$query->bind_param("sss", $username, $comment, $date);
		$query->execute();
		$query->close();
		$this->mysqli->autocommit(True);
                $this->LogActivity($username, "Forum", "{$comment} have been shared by {$username}");
            }catch(Exception $e){
		$this->mysqli->rollback();	
            }
      
        }
        
        function printComment()
        {
            include("config.php");
            include("lang.php");
			
            try{    
		$this->mysqli->autocommit(False);
		$query = $this->mysqli->prepare("SELECT `username`, `comment`, `date` FROM `comments` order by `date` DESC ");              
		$query->execute();
		$result = $query->get_result();
		$query->close();
		$this->mysqli->autocommit(True);
		return $result; 
            }catch(Exception $e){
		$this->mysqli->rollback();	
            }
        }
        
        function printFilmsAll()
        {
            
            include("config.php");
            include("lang.php");
            
			
			try{    
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("SELECT F.Film_ID, F.Film_Name, F.Film_Title, F.Film_Information, F.Film_Banner  FROM cinema_films F  order by F.Film_Name ASC ");         
				
                $query->execute();
				$result = $query->get_result();
				$query->close();
				$this->mysqli->autocommit(True);
				return $result; 
			}catch(Exception $e){
				$this->mysqli->rollback();	
			}
        }
        
        function printFilms($typeid)
        {
            
            include("config.php");
            include("lang.php");
            
			
			try{    
                                $typeid = intval($typeid);
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("SELECT F.`Film_ID`, F.`Film_Name`,F.`Film_Title`,F.`Film_Information`,F.`Film_Banner`  FROM `cinema_films` F, `typing` T WHERE T.`Film_ID` = F.`Film_ID` AND T.`Type_ID` = ? order by `Film_Name` DESC LIMIT 10 ");         
				$query->bind_param("i", $typeid);
                $query->execute();
				$result = $query->get_result();
				$query->close();
				$this->mysqli->autocommit(True);
				return $result; 
			}catch(Exception $e){
				$this->mysqli->rollback();	
			}
        
        }
        
        function getFilm_ID($filmname,$filminfo){
            include("config.php");
            try{
                $this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("SELECT `Film_ID` FROM `Cinema_Films` WHERE `Film_Name` = ? AND `Film_Information`=? ");
		$query->bind_param("ss", $filmname,$filminfo);
		$query->execute();
                $film_id = $query->get_result();
		$query->close();
                $this->mysqli->autocommit(True);
                return $film_id;
            } catch (Exception $e){
                $this->mysqli->rollback();
            }
        }
        
        function getCompanyID ($companyname){
            include("config.php");
            try{
                $this->mysqli->autocommit(False);
                $query = $this->mysqli->prepare("SELECT `Company_ID` FROM `Producer_Company` WHERE `Company_Name` = ? ");
		$query->bind_param("s", $companyname);
		$query->execute();
                $company_id = $query->get_result();
		$query->close();
                $this->mysqli->autocommit(True);
                return $company_id;
            } catch (Exception $e){
                $this->mysqli->rollback();
            }
            
        }
        
                
        function insertFilm($filmname,$filmtitle, $filmtime, $filmbanner, $filminfo,$filmtypes,$filmyear,$director,$companyname, $username){
			include("config.php");
                
            try{ 
                
                $this->mysqli->autocommit(False);
		$query = $this->mysqli->prepare("INSERT INTO `Cinema_Films`( `Film_Name`, `Film_Title`, `Film_Duration`, `Film_Banner`, `Film_Information`) VALUES  ( ?, ?, ?,?, ?)");
		$query->bind_param("sssss", $filmname,$filmtitle, $filmtime, $filmbanner, $filminfo);
		$query->execute();
		$query->close();
						
						
		$Ffilm_id = $this->getFilm_ID($filmname,$filminfo);
		$film_id = $Ffilm_id->fetch_assoc();
		$film_id = $film_id['Film_ID'];
		$film_id = intval($film_id); 
					
		foreach ($filmtypes as $filmtype){
					
			$filmtype = intval($filmtype);
			$query2 = $this->mysqli->prepare("INSERT INTO `Typing`( `Film_ID`, `Type_ID`) VALUES  ( ?, ?)");
			$query2->bind_param("ii", $film_id,$filmtype);
			$query2->execute();
			$query2->close();
		}
				
						
				
		$director_id = intval($director);				
		$query3 = $this->mysqli->prepare("INSERT INTO `Manage`( `Film_ID`, `Person_ID`) VALUES  ( ?, ?)");
		$query3->bind_param("ii", $film_id,$director_id);
		$query3->execute();
		$query3->close();
                
                
                
                $company_id = $this->getCompanyID($companyname);
                $company_id = $company_id->fetch_assoc()['Company_ID'];
                
                
                $query4 = $this->mysqli->prepare("INSERT INTO `Make`( `Film_ID`, `Company_ID`) VALUES  ( ?, ?)");
		$query4->bind_param("ii", $film_id,$company_id);
		$query4->execute();
		$query4->close();
						
						
		$this->LogActivity($username, "Insert", "{$filmname} have been inserted by {$username}");
		$this->mysqli->autocommit(True);
                }catch(Exception $e){
                    echo 'hata çıkyır';
                    $this->mysqli->rollback();	
		}       
	}




        /*
	* Log user in via MySQL Database
	* @param string $username
	* @param string $password
	* @return boolean
	*/
	
	function login($username, $password)
	{
		include("config.php");
		include("lang.php");
		
		if(!isset($_COOKIE["auth_session"]))
		{
			$attcount = $this->getattempt($_SERVER['REMOTE_ADDR']);
			
			if($attcount >= $auth_conf['max_attempts'])
			{
				$this->errormsg[] = $lang[$loc]['auth']['login_lockedout'];
				$this->errormsg[] = $lang[$loc]['auth']['login_wait30'];
				
				return false;
			}
			else 
			{
				// Input verification :
			
				if(strlen($username) == 0) { $this->errormsg[] = $lang[$loc]['auth']['login_username_empty']; return false; }
				elseif(strlen($username) > 30) { $this->errormsg[] = $lang[$loc]['auth']['login_username_long']; return false; }
				elseif(strlen($username) < 3) { $this->errormsg[] = $lang[$loc]['auth']['login_username_short']; return false; }
				elseif(strlen($password) == 0) { $this->errormsg[] = $lang[$loc]['auth']['login_password_empty']; return false; }
				elseif(strlen($password) > 30) { $this->errormsg[] = $lang[$loc]['auth']['login_password_short']; return false; }
				elseif(strlen($password) < 5) { $this->errormsg[] = $lang[$loc]['auth']['login_password_long']; return false; }
				else 
				{
					// Input is valid
				
					$password = $this->hashpass($password);
					
					try{    
						$this->mysqli->autocommit(False);
					
						$query = $this->mysqli->prepare("SELECT isactive FROM users WHERE username = ? AND password = ?");
						$query->bind_param("ss", $username, $password);
						$query->bind_result($isactive);
						$query->execute();
						$query->store_result();
						$count = $query->num_rows;
						$query->fetch();
						$query->close();
						$this->mysqli->autocommit(True);
				
					}catch(Exception $e){
						$this->mysqli->rollback();	
					}
					
					
				
					if($count == 0)
					{
						// Username and / or password are incorrect
					
						$this->errormsg[] = $lang[$loc]['auth']['login_incorrect'];
						
						$this->addattempt($_SERVER['REMOTE_ADDR']);
						
						$attcount = $attcount + 1;
						$remaincount = $auth_conf['max_attempts'] - $attcount;
						
						$this->LogActivity("UNKNOWN", "AUTH_LOGIN_FAIL", "Username / Password incorrect - {$username} / {$password}");
						
						$this->errormsg[] = sprintf($lang[$loc]['auth']['login_attempts_remaining'], $remaincount);
						
						return false;
					}
					else 
					{
						// Username and password are correct
						
							// Account is activated
							
							$this->newsession($username);				
							$this->LogActivity($username, "AUTH_LOGIN_SUCCESS", "User logged in");
					
							$this->successmsg[] = $lang[$loc]['auth']['login_success'];
							
							return true;
						
					}
				}
			}
		}
		else 
		{
			// User is already logged in
			
			$this->errormsg[] = $lang[$loc]['auth']['login_already'];
			
			return false;
		}
	}
	
	/*
	* Register a new user into the database
	* @param string $username
	* @param string $password
	* @param string $verifypassword
	* @param string $email
	* @return boolean
	*/
	
	function register($username, $password, $verifypassword, $email)
	{
		include("config.php");
		include("lang.php");
                
		if(!isset($_COOKIE["auth_session"]))
		{
		
			// Input Verification :
		
			if(strlen($username) == 0) { $this->errormsg[] = $lang[$loc]['auth']['register_username_empty']; }
			elseif(strlen($username) > 30) { $this->errormsg[] = $lang[$loc]['auth']['register_username_long']; }
			elseif(strlen($username) < 3) { $this->errormsg[] = $lang[$loc]['auth']['register_username_short']; }
			if(strlen($password) == 0) { $this->errormsg[] = $lang[$loc]['auth']['register_password_empty']; }
			elseif(strlen($password) > 30) { $this->errormsg[] = $lang[$loc]['auth']['register_password_long']; }
			elseif(strlen($password) < 5) { $this->errormsg[] = $lang[$loc]['auth']['register_password_short']; }
			elseif($password !== $verifypassword) { $this->errormsg[] = $lang[$loc]['auth']['register_password_nomatch']; }
			elseif(strstr($password, $username)) { $this->errormsg[] = $lang[$loc]['auth']['register_password_username']; }
			if(strlen($email) == 0) { $this->errormsg[] = $lang[$loc]['auth']['register_email_empty']; }
			elseif(strlen($email) > 100) { $this->errormsg[] = $lang[$loc]['auth']['register_email_long']; }
			elseif(strlen($email) < 5) { $this->errormsg[] = $lang[$loc]['auth']['register_email_short']; }
			elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) { $this->errormsg[] = $lang[$loc]['auth']['register_email_invalid']; }
		
			if(count($this->errormsg) == 0)
			{
				// Input is valid
                                $this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("SELECT * FROM users WHERE username=?");
				$query->bind_param("s", $username);
				$query->execute();
				$query->store_result();
				$count = $query->num_rows;
				$query->close();
                                $this->mysqli->autocommit(True);
			
				if($count != 0)
				{
					// Username already exists
                                        
					$this->LogActivity("UNKNOWN", "AUTH_REGISTER_FAIL", "Username ({$username}) already exists");
				
					$this->errormsg[] = $lang[$loc]['auth']['register_username_exist'];
					
					return false;
				}
				else 
				{
					// Username is not taken
                                        $this->mysqli->autocommit(False);
					$query = $this->mysqli->prepare("SELECT * FROM users WHERE email=?");
					$query->bind_param("s", $email);
					$query->execute();
					$query->store_result();
					$count = $query->num_rows;
					$query->close();
                                        $this->mysqli->autocommit(True);
				
					if($count != 0)
					{
						// Email address is already used
					
						$this->LogActivity("UNKNOWN", "AUTH_REGISTER_FAIL", "Email ({$email}) already exists");
					
						$this->errormsg[] = $lang[$loc]['auth']['register_email_exist'];
						
						return false;					
					}
					else 
					{
						// Email address isn't already used
					
						$password = $this->hashpass($password);
						$activekey = $this->randomkey(15);	 
                         
						try{    
							$this->mysqli->autocommit(False);
						 
							$query = $this->mysqli->prepare("INSERT INTO users (username, password, email, activekey) VALUES (?, ?, ?, ?)");
							$query->bind_param("ssss", $username, $password, $email, $activekey);
							$query->execute();
							$query->close();
							
							$this->mysqli->autocommit(True);
				
						}catch(Exception $e){
							$this->mysqli->rollback();	
						}
                                          
										  
                                                
						/***
						$message_from = $auth_conf['email_from'];
						$message_subj = $auth_conf['site_name'] . " - Account activation required !";
						$message_cont = "Hello {$username}<br/><br/>";
						$message_cont .= "You recently registered a new account on " . $auth_conf['site_name'] . "<br/>";
						$message_cont .= "To activate your account please click the following link<br/><br/>";
						$message_cont .= "<b><a href=\"" . $auth_conf['base_url'] . "?page=activate&username={$username}&key={$activekey}\">Activate my account</a></b>";
						$message_head = "From: {$message_from}" . "\r\n";
						$message_head .= "MIME-Version: 1.0" . "\r\n";
						$message_head .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";
						
						mail($email, $message_subj, $message_cont, $message_head);
                                                */
                                                
						$this->LogActivity($username, "AUTH_REGISTER_SUCCESS", "Account created and activation email sent");
					
						$this->successmsg[] = $lang[$loc]['auth']['register_success'];
						
						return true;					
					}
				}			
			}
			else 
			{
				return false;
			}
		}
		else 
		{
			// User is logged in
		
			$this->errormsg[] = $lang[$loc]['auth']['register_email_loggedin'];
			
			return false;
		}
	}
	
	/*
	* Creates a new session for the provided username and sets cookie
	* @param string $username
	*/
	
	function newsession($username)
	{
		include("config.php");
	
		$hash = md5(microtime());
		
		// Fetch User ID :		
		try{    
                    $this->mysqli->autocommit(False);
                    $query = $this->mysqli->prepare("SELECT id FROM users WHERE username=?");
                    $query->bind_param("s", $username);
                    $query->bind_result($uid);
                    $query->execute();
                    $query->fetch();
                    $query->close();
                    $this->mysqli->autocommit(True);
                }catch(Exception $e){
                    $this->mysqli->rollback();
                }
		
		// Delete all previous sessions :
		try{    
                    $this->mysqli->autocommit(False);
                    $query = $this->mysqli->prepare("DELETE FROM sessions WHERE username=?");
                    $query->bind_param("s", $username);
                    $query->execute();
                    $query->close();
                    $this->mysqli->autocommit(True);
                }catch(Exception $e){
                    $this->mysqli->rollback();
                }
                 
		
		$ip = $_SERVER['REMOTE_ADDR'];
		$expiredate = date("Y-m-d H:i:s", strtotime($auth_conf['session_duration']));
		$expiretime = strtotime($expiredate);
		
                try{    
                    $this->mysqli->autocommit(False);
                    $query = $this->mysqli->prepare("INSERT INTO sessions (uid, username, hash, expiredate, ip) VALUES (?, ?, ?, ?, ?)");
                    $query->bind_param("issss", $uid, $username, $hash, $expiredate, $ip);
                    $query->execute();
                    $query->close();
                    $this->mysqli->autocommit(True);
                }catch(Exception $e){
                    $this->mysqli->rollback();
                }
                
		setcookie("auth_session", $hash, $expiretime);
	}
	
	/*
	* Deletes the user's session based on hash
	* @param string $hash
	*/
	
	function deletesession($hash)
	{
		include("config.php");
		include("lang.php");
	
                try{    
                    $this->mysqli->autocommit(False);
                    $query = $this->mysqli->prepare("SELECT username FROM sessions WHERE hash=?");
                    $query->bind_param("s", $hash);
                    $query->bind_result($username);
                    $query->execute();
                    $query->store_result();
                    $count = $query->num_rows;
                    $query->fetch();
                    $query->close();
                    $this->mysqli->autocommit(True);
                }catch(Exception $e){
                    $this->mysqli->rollback();
                }
                
                
		if($count == 0)
		{
			// Hash doesn't exist
			
			$this->LogActivity("UNKNOWN", "AUTH_LOGOUT", "User session cookie deleted - Database session not deleted - Hash ({$hash}) didn't exist");
		
			$this->errormsg[] = $lang[$loc]['auth']['deletesession_invalid'];
			
			setcookie("auth_session", $hash, time() - 3600);
		}
		else 
		{
			// Hash exists, Delete all sessions for that username :
			try{    
                            $this->mysqli->autocommit(False);
                            $query = $this->mysqli->prepare("DELETE FROM sessions WHERE username=?");
                            $query->bind_param("s",$username);

                            $query->execute();
                            $query->close();
                            
                            $this->mysqli->autocommit(True);
                        }catch(Exception $e){
                            $this->mysqli->rollback();
                        }
			$this->LogActivity($username, "AUTH_LOGOUT", "User session cookie deleted - Database session deleted - Hash ({$hash})");
			
			setcookie("auth_session", $hash, time() - 3600);
		}
	}
	
	/*
	* Provides an associative array of user info based on session hash
	* @param string $hash
	* @return array $session
	*/
	
	function sessioninfo($hash)
	{
		include("config.php");
		include("lang.php");
	
                try{    
                    $this->mysqli->autocommit(False);
                    $query = $this->mysqli->prepare("SELECT uid, username, expiredate, ip FROM sessions WHERE hash=?");
                    $query->bind_param("s", $hash);
                    $query->bind_result($session['uid'], $session['username'], $session['expiredate'], $session['ip']);
                    $query->execute();
                    $query->store_result();
                    $count = $query->num_rows;
                    $query->fetch();
                    $query->close();
                    $this->mysqli->autocommit(True);
                }catch(Exception $e){
                    $this->mysqli->rollback();
                }
                        
                        
		if($count == 0)
		{
			// Hash doesn't exist
		
			$this->errormsg[] = $lang[$loc]['auth']['sessioninfo_invalid'];
			
			setcookie("auth_session", $hash, time() - 3600);
			
			return false;
		}
		else 
		{
			// Hash exists
		
			return $session;			
		}
	}
	
	/* 
	* Checks if session is valid (Current IP = Stored IP + Current date < expire date)
	* @param string $hash
	* @return bool
	*/
	
	function checksession($hash)
	{
                try{    
                    $this->mysqli->autocommit(False);
                    $query = $this->mysqli->prepare("SELECT username, expiredate, ip FROM sessions WHERE hash=?");
                    $query->bind_param("s", $hash);
                    $query->bind_result($username, $db_expiredate, $db_ip);
                    $query->execute();
                    $query->store_result();
                    $count = $query->num_rows;
                    $query->fetch();
                    $query->close();
                    $this->mysqli->autocommit(True);
                }catch(Exception $e){
                    $this->mysqli->rollback();
                }
		if($count == 0)
		{
			// Hash doesn't exist
			
			setcookie("auth_session", $hash, time() - 3600);
			
			$this->LogActivity($username, "AUTH_CHECKSESSION", "User session cookie deleted - Hash ({$hash}) didn't exist");
			
			return false;
		}
		else
		{
			if($_SERVER['REMOTE_ADDR'] != $db_ip)
			{
				// Hash exists, but IP has changed
			
                                try{    
                                    $this->mysqli->autocommit(False);
                                    $query = $this->mysqli->prepare("DELETE FROM sessions WHERE username=?");
                                    $query->bind_param("s", $username);
                                    $query->execute();
                                    $query->close();
                                    $this->mysqli->autocommit(True);
                                }catch(Exception $e){
                                    $this->mysqli->rollback();
                                }
				setcookie("auth_session", $hash, time() - 3600);
				
				$this->LogActivity($username, "AUTH_CHECKSESSION", "User session cookie deleted - IP Different ( DB : {$db_ip} / Current : " . $_SERVER['REMOTE_ADDR'] . " )");
				
				return false;
			}
			else 
			{
				$expiredate = strtotime($db_expiredate);
				$currentdate = strtotime(date("Y-m-d H:i:s"));
				
				if($currentdate > $expiredate)
				{
					// Hash exists, IP is the same, but session has expired
                                        try{    
                                            $this->mysqli->autocommit(False);
                                            $query = $this->mysqli->prepare("DELETE FROM sessions WHERE username=?");
                                            $query->bind_param("s", $username);
                                            $query->execute();
                                            $query->close();
                                            $this->mysqli->autocommit(True);
                                        }catch(Exception $e){
                                            $this->mysqli->rollback();
                                        }
                                
                                
					setcookie("auth_session", $hash, time() - 3600);
					
					$this->LogActivity($username, "AUTH_CHECKSESSION", "User session cookie deleted - Session expired ( Expire date : {$db_expiredate} )");
					
					return false;
				}
				else 
				{
					// Hash exists, IP is the same, date < expiry date
				
					return true;
				}
			}
		}
	}
	
	/*
	* Returns a random string, length can be modified
	* @param int $length
	* @return string $key
	*/
	
	function randomkey($length = 10)
	{
		$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
		$key = "";
		
		for($i = 0; $i < $length; $i++)
		{
			$key .= $chars{rand(0, strlen($chars) - 1)};
		}
		
		return $key;
	}
	
	/*
	* Activate a user's account
	* @param string $username
	* @param string $key
	* @return boolean
	*/
	
	function activate($username, $key)
	{
		include("config.php");
		include("lang.php");
	
		// Input verification
	
		if(strlen($username) == 0) { $this->errormsg[] = $lang[$loc]['auth']['activate_username_empty']; return false; }
		elseif(strlen($username) > 30) { $this->errormsg[] = $lang[$loc]['auth']['activate_username_long']; return false; }
		elseif(strlen($username) < 3) { $this->errormsg[] = $lang[$loc]['auth']['activate_username_short']; return false; }
		elseif(strlen($key) == 0) { $this->errormsg[] = $lang[$loc]['auth']['activate_key_empty']; return false; }
		elseif(strlen($key) > 15) { $this->errormsg[] = $lang[$loc]['auth']['activate_key_long']; return false; }
		elseif(strlen($key) < 15) { $this->errormsg[] = $lang[$loc]['auth']['activate_key_short']; return false; }
		else
		{
			// Input is valid
			try{    
                            $this->mysqli->autocommit(False);
                            $query = $this->mysqli->prepare("SELECT isactive, activekey FROM users WHERE username=?");
                            $query->bind_param("s", $username);
                            $query->bind_result($isactive, $activekey);
                            $query->execute();
                            $query->store_result();
                            $count = $query->num_rows;
                            $query->fetch();
                            $query->close();
                            $this->mysqli->autocommit(True);
                        }catch(Exception $e){
                            $this->mysqli->rollback();
                        }
                                        
                                        
			if($count == 0)
			{
				// User doesn't exist
				
				$this->LogActivity("UNKNOWN", "AUTH_ACTIVATE_FAIL", "Username Incorrect : {$username}");				
				
				$this->errormsg[] = $lang[$loc]['auth']['activate_username_incorrect'];
				
				return false;
			}
			else
			{
				// User exists
				
				if($isactive == 1)
				{
					// Account is already activated
					
					$this->LogActivity($username, "AUTH_ACTIVATE_FAIL", "Account already activated");					
					
					$this->errormsg[] = $lang[$loc]['auth']['activate_account_activated'];
					
					return true;
				}
				else
				{
					// Account isn't activated
					
					if($key == $activekey)
					{
						// Activation keys match
						
						$new_isactive = 1;
						$new_activekey = "0";
						
						$query = $this->mysqli->prepare("UPDATE users SET isactive=?, activekey=? WHERE username=?");
						$query->bind_param("iss", $new_isactive, $new_activekey, $username);
						$query->execute();
						$query->close();
						
						$this->LogActivity($username, "AUTH_ACTIVATE_SUCCESS", "Activation successful. Key Entry deleted.");						
						
						$this->successmsg[] = $lang[$loc]['auth']['activate_success'];
						return true;						
					}
					else
					{
						// Activation Keys don't match
						
						$this->LogActivity($username, "AUTH_ACTIVATE_FAIL", "Activation keys don't match ( DB : {$activekey} / Given : {$key} )");						
						
						$this->errormsg[] = $lang[$loc]['auth']['activate_key_incorrect'];
						
						return false;
					}
				}
			}
		}
	}
	
	/*
	* Changes a user's password, providing the current password is known
	* @param string $username
	* @param string $currpass
	* @param string $newpass
	* @param string $verifynewpass
	* @return boolean
	*/
	
	function changepass($username, $currpass, $newpass, $verifynewpass)
	{
		include("config.php");
		include("lang.php");
		
		if(strlen($username) == 0) { $this->errormsg[] = $lang[$loc]['auth']['changepass_username_empty']; }
		elseif(strlen($username) > 30) { $this->errormsg[] = $lang[$loc]['auth']['changepass_username_long']; }
		elseif(strlen($username) < 3) { $this->errormsg[] = $lang[$loc]['auth']['changepass_username_short']; }
		if(strlen($currpass) == 0) { $this->errormsg[] = $lang[$loc]['auth']['changepass_currpass_empty']; }
		elseif(strlen($currpass) < 5) { $this->errormsg[] = $lang[$loc]['auth']['changepass_currpass_short']; }
		elseif(strlen($currpass) > 30) { $this->errormsg[] = $lang[$loc]['auth']['changepass_currpass_long']; }
		if(strlen($newpass) == 0) { $this->errormsg[] = $lang[$loc]['auth']['changepass_newpass_empty']; }
		elseif(strlen($newpass) < 5) { $this->errormsg[] = $lang[$loc]['auth']['changepass_newpass_short']; }
		elseif(strlen($newpass) > 30) { $this->errormsg[] = $lang[$loc]['auth']['changepass_newpass_long']; }
		elseif(strstr($newpass, $username)) { $this->errormsg[] = $lang[$loc]['auth']['changepass_password_username']; }
		elseif($newpass !== $verifynewpass) { $this->errormsg[] = $lang[$loc]['auth']['changepass_password_nomatch']; }
		
		if(count($this->errormsg) == 0)
		{
			$currpass = $this->hashpass($currpass);
			$newpass = $this->hashpass($newpass);
			
                        try{    
                            $this->mysqli->autocommit(False);
                            $query = $this->mysqli->prepare("SELECT password FROM users WHERE username=?");
                            $query->bind_param("s", $username);
                            $query->bind_result($db_currpass);
                            $query->execute();
                            $query->store_result();
                            $count = $query->num_rows;
                            $query->fetch();
                            $query->close();
                            $this->mysqli->autocommit(True);
                        }catch(Exception $e){
                            $this->mysqli->rollback();
                        }
                        
                        
			if($count == 0)
			{
				$this->LogActivity("UNKNOWN", "AUTH_CHANGEPASS_FAIL", "Username Incorrect ({$username})");				
				
				$this->errormsg[] = $lang[$loc]['auth']['changepass_username_incorrect'];
				return false;
			}
			else 
			{
				if($currpass == $db_currpass)
				{
                                        try{    
                                            $this->mysqli->autocommit(False);
                                            $query = $this->mysqli->prepare("UPDATE users SET password=? WHERE username=?");
                                            $query->bind_param("ss", $newpass, $username);
                                            $query->execute();
                                            $query->close();
                                            $this->mysqli->autocommit(True);
                                        }catch(Exception $e){
                                            $this->mysqli->rollback();
                                        }
                        
					$this->LogActivity($username, "AUTH_CHANGEPASS_SUCCESS", "Password changed");					
					
					$this->successmsg[] = $lang[$loc]['auth']['changepass_success'];
					
					return true;
				}
				else 
				{
					$this->LogActivity($username, "AUTH_CHANGEPASS_FAIL", "Current Password Incorrect ( DB : {$db_currpass} / Given : {$currpass} )");					
					
					$this->errormsg[] = $lang[$loc]['auth']['changepass_currpass_incorrect'];
									  
					return false;
				}
			}
		}
		else 
		{
			return false;
		}
	}
	
	/*
	* Changes the stored email address based on username
	* @param string $username
	* @param string $email
	* @return boolean
	*/
	
	function changeemail($username, $email)
	{
		include("config.php");
		include("lang.php");
		
		if(strlen($username) == 0) { $this->errormsg[] = $lang[$loc]['auth']['changeemail_username_empty']; }
		elseif(strlen($username) > 30) { $this->errormsg[] = $lang[$loc]['auth']['changeemail_username_long']; }
		elseif(strlen($username) < 3) { $this->errormsg[] = $lang[$loc]['auth']['changeemail_username_short']; }
		if(strlen($email) == 0) { $this->errormsg[] = $lang[$loc]['auth']['changeemail_email_empty']; }
		elseif(strlen($email) > 100) { $this->errormsg[] = $lang[$loc]['auth']['changeemail_email_long']; }
		elseif(strlen($email) < 5) { $this->errormsg[] = $lang[$loc]['auth']['changeemail_email_short']; }
		elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) { $this->errormsg[] = $lang[$loc]['auth']['changeemail_email_invalid']; }
		
		if(count($this->errormsg) == 0)
		{
                        try{    
                            $this->mysqli->autocommit(False);
                            $query = $this->mysqli->prepare("SELECT email FROM users WHERE username=?");
                            $query->bind_param("s", $username);
                            $query->bind_result($db_email);
                            $query->execute();
                            $query->store_result();
                            $count = $query->num_rows;
                            $query->fetch();
                            $query->close();
                            $this->mysqli->autocommit(True);
                        }catch(Exception $e){
                            $this->mysqli->rollback();
                        }
                                        
                                        
                                        
			if($count == 0)
			{
				$this->LogActivity("UNKNOWN", "AUTH_CHANGEEMAIL_FAIL", "Username Incorrect ({$username})");				
				
				$this->errormsg[] = $lang[$loc]['auth']['changeemail_username_incorrect'];
				
				return false;
			}
			else 
			{
				if($email == $db_email)
				{
 					$this->LogActivity($username, "AUTH_CHANGEEMAIL_FAIL", "Old and new email matched ({$email})");				   
					
					$this->errormsg[] = $lang[$loc]['auth']['changeemail_email_match'];
					
					return false;
				}
				else 
				{
                                        try{    
											echo "email değiştiriliyor!!!";
                                            $this->mysqli->autocommit(False);
                                            $query = $this->mysqli->prepare("UPDATE users SET email=? WHERE username=?");
                                            $query->bind_param("ss", $email, $username);
                                            $query->execute();
                                            $query->close();
                                            $this->mysqli->autocommit(True);
                                        }catch(Exception $e){
                                            $this->mysqli->rollback();
                                        }
                        
                        
					$this->LogActivity($username, "AUTH_CHANGEEMAIL_SUCCESS", "Email changed from {$db_email} to {$email}");					
					
					$this->successmsg[] = $lang[$loc]['auth']['changeemail_success'];
					
					return true;
				}
			}
		}
		else 
		{
			return false;
		}
	}
	
	/*
	* Give the user the ability to change their password if the current password is forgotten
	* by sending email to the email address associated to that user
	* @param string $username
	* @param string $email
	* @param string $key
	* @param string $newpass
	* @param string $verifynewpass
	* @return boolean
	*/
	
	function resetpass($username = '0', $email ='0', $key = '0', $newpass = '0', $verifynewpass = '0')
	{
		include("config.php");
		include("lang.php");
	
		$attcount = $this->getattempt($_SERVER['REMOTE_ADDR']);
			
		if($attcount >= $auth_conf['max_attempts'])
		{
			$this->errormsg[] = $lang[$loc]['auth']['resetpass_lockedout'];
			$this->errormsg[] = $lang[$loc]['auth']['resetpass_wait30'];
				
			return false;
		}
		else
		{
			if($username == '0' && $key == '0')
			{
				if(strlen($email) == 0) { $this->errormsg[] = $lang[$loc]['auth']['resetpass_email_empty']; }
				elseif(strlen($email) > 100) { $this->errormsg[] = $lang[$loc]['auth']['resetpass_email_long']; }
				elseif(strlen($email) < 5) { $this->errormsg[] = $lang[$loc]['auth']['resetpass_email_short']; }
				elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) { $this->errormsg[] = $lang[$loc]['auth']['resetpass_email_invalid']; }
				
				$resetkey = $this->randomkey(15);
				
				$query = $this->mysqli->prepare("SELECT username FROM users WHERE email=?");
				$query->bind_param("s", $email);
				$query->bind_result($username);
				$query->execute();
				$query->store_result();
				$count = $query->num_rows;
				$query->fetch();
				$query->close();
				
				if($count == 0)
				{
					$this->errormsg[] = $lang[$loc]['auth']['resetpass_email_incorrect'];
					
					$attcount = $attcount + 1;
					$remaincount = $auth_conf['max_attempts'] - $attcount;
					   
					$this->LogActivity("UNKNOWN", "AUTH_RESETPASS_FAIL", "Email incorrect ({$email})");
					   
					$this->errormsg[] = sprintf($lang[$loc]['auth']['resetpass_attempts_remaining'], $remaincount);
						
					$this->addattempt($_SERVER['REMOTE_ADDR']);
						
					return false;
				}
				else
				{
                                        
					$query = $this->mysqli->prepare("UPDATE users SET resetkey=? WHERE username=?");
					$query->bind_param("ss", $resetkey, $username);
					$query->execute();
					$query->close();
					
					$message_from = $auth_conf['email_from'];
					$message_subj = $auth_conf['site_name'] . " - Password reset request !";
					$message_cont = "Hello {$username}<br/><br/>";
					$message_cont .= "You recently requested a password reset on " . $auth_conf['site_name'] . "<br/>";
					$message_cont .= "To proceed with the password reset, please click the following link :<br/><br/>";
					$message_cont .= "<b><a href=\"" . $auth_conf['base_url'] . "?page=forgot&username={$username}&key={$resetkey}\">Reset My Password</a></b>";
					$message_head = "From: {$message_from}" . "\r\n";
					$message_head .= "MIME-Version: 1.0" . "\r\n";
					$message_head .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";
						
					mail($email, $message_subj, $message_cont, $message_head);
					
					$this->LogActivity($username, "AUTH_RESETPASS_SUCCESS", "Reset pass request sent to {$email} ( Key : {$resetkey} )");
					
					$this->successmsg[] = $lang[$loc]['auth']['resetpass_email_sent'];
						
					return true;
				}
			}
			else
			{
				// Reset Password
				
				if(strlen($key) == 0) { $this->errormsg[] = $lang[$loc]['auth']['resetpass_key_empty']; }
				elseif(strlen($key) < 15) { $this->errormsg[] = $lang[$loc]['auth']['resetpass_key_short']; }
				elseif(strlen($key) > 15) { $this->errormsg[] = $lang[$loc]['auth']['resetpass_key_long']; }
				if(strlen($newpass) == 0) { $this->errormsg[] = $lang[$loc]['auth']['resetpass_newpass_empty']; }
				elseif(strlen($newpass) > 30) { $this->errormsg[] = $lang[$loc]['auth']['resetpass_newpass_long']; }
				elseif(strlen($newpass) < 5) { $this->errormsg[] = $lang[$loc]['auth']['resetpass_newpass_short']; }
				elseif(strstr($newpass, $username)) { $this->errormsg[] = $lang[$loc]['auth']['resetpass_newpass_username']; }
				elseif($newpass !== $verifynewpass) { $this->errormsg[] = $lang[$loc]['auth']['resetpass_newpass_nomatch']; }
				
				if(count($this->errormsg) == 0)
				{
					$query = $this->mysqli->prepare("SELECT resetkey FROM users WHERE username=?");
					$query->bind_param("s", $username);
					$query->bind_result($db_key);
					$query->execute();
					$query->store_result();
					$count = $query->num_rows;
					$query->fetch();
					$query->close();
					
					if($count == 0)
					{
						$this->errormsg[] = $lang[$loc]['auth']['resetpass_username_incorrect'];
						
						$attcount = $attcount + 1;
						$remaincount = $auth_conf['max_attempts'] - $attcount;
						
						$this->LogActivity("UNKNOWN", "AUTH_RESETPASS_FAIL", "Username incorrect ({$username})");						
						
						$this->errormsg[] = sprintf($lang[$loc]['auth']['resetpass_attempts_remaining'], $remaincount);
						
						$this->addattempt($_SERVER['REMOTE_ADDR']);
						
						return false;
					}
					else
					{
						if($key == $db_key)
						{
							$newpass = $this->hashpass($newpass);
							
							$resetkey = '0';
						
							$query = $this->mysqli->prepare("UPDATE users SET password=?, resetkey=? WHERE username=?");
							$query->bind_param("sss", $newpass, $resetkey, $username);
							$query->execute();
							$query->close();
							
							$this->LogActivity($username, "AUTH_RESETPASS_SUCCESS", "Password reset - Key reset");							
							
							$this->successmsg[] = $lang[$loc]['auth']['resetpass_success'];
							
							return true;
						}
						else
						{
							$this->errormsg[] = $lang[$loc]['auth']['resetpass_key_incorrect'];
							
							$attcount = $attcount + 1;
							$remaincount = 5 - $attcount;
						
							$this->LogActivity($username, "AUTH_RESETPASS_FAIL", "Key Incorrect ( DB : {$db_key} / Given : {$key} )");						
						
							$this->errormsg[] = sprintf($lang[$loc]['auth']['resetpass_attempts_remaining'], $remaincount);
						
							$this->addattempt($_SERVER['REMOTE_ADDR']);
 
							return false;
						}
					}
				}
				else
				{
					return false;
				}
			}
		}
	}
	
	/*
	* Checks if the reset key is correct for provided username
	* @param string $username
	* @param string $key
	* @return boolean
	*/
	
	function checkresetkey($username, $key)
	{
		include("config.php");
		include("lang.php");
		
		$attcount = $this->getattempt($_SERVER['REMOTE_ADDR']);
			
		if($attcount >= $auth_conf['max_attempts'])
		{
			$this->errormsg[] = $lang[$loc]['auth']['resetpass_lockedout'];
			$this->errormsg[] = $lang[$loc]['auth']['resetpass_wait30'];
				
			return false;
		}
		else
		{
		
			if(strlen($username) == 0) { return false; }
			elseif(strlen($username) > 30) { return false; }
			elseif(strlen($username) < 3) { return false; }
			elseif(strlen($key) == 0) { return false; }
			elseif(strlen($key) < 15) { return false; }
			elseif(strlen($key) > 15) { return false; }
			else
			{
				$query = $this->mysqli->prepare("SELECT resetkey FROM users WHERE username=?");
				$query->bind_param("s", $username);
				$query->bind_result($db_key);
				$query->execute();
				$query->store_result();
				$count = $query->num_rows;
				$query->fetch();
				$query->close();
				
				if($count == 0)
				{
					$this->LogActivity("UNKNOWN", "AUTH_CHECKRESETKEY_FAIL", "Username doesn't exist ({$username})");
						
					$this->addattempt($_SERVER['REMOTE_ADDR']);
						
					$this->errormsg[] = $lang[$loc]['auth']['checkresetkey_username_incorrect'];
						
					$attcount = $attcount + 1;
					$remaincount = $auth_conf['max_attempts'] - $attcount;
						
					$this->errormsg[] = sprintf($lang[$loc]['auth']['checkresetkey_attempts_remaining'], $remaincount);
				
					return false;
				}
				else
				{
					if($key == $db_key)
					{
						return true;
					}
					else
					{
						$this->LogActivity($username, "AUTH_CHECKRESETKEY_FAIL", "Key provided is different to DB key ( DB : {$db_key} / Given : {$key} )");
						
						$this->addattempt($_SERVER['REMOTE_ADDR']);
						
						$this->errormsg[] = $lang[$loc]['auth']['checkresetkey_key_incorrect'];
						
						$attcount = $attcount + 1;
						$remaincount = $auth_conf['max_attempts'] - $attcount;
						
						$this->errormsg[] = sprintf($lang[$loc]['auth']['checkresetkey_attempts_remaining'], $remaincount);
					
						return false;
					}
				}
			}
		}
	}
	
	/*
	* Deletes a user's account. Requires user's password
	* @param string $username
	* @param string $password
	* @return boolean
	*/
	
	function deleteaccount($username, $password)
	{
		include("config.php");
		include("lang.php");
	
		if(strlen($username) == 0) { $this->errormsg[] = $lang[$loc]['auth']['deleteaccount_username_empty']; }
		elseif(strlen($username) > 30) { $this->errormsg[] = $lang[$loc]['auth']['deleteaccount_username_long']; }
		elseif(strlen($username) < 3) { $this->errormsg[] = $lang[$loc]['auth']['deleteaccount_username_short']; }
		if(strlen($password) == 0) { $this->errormsg[] = $lang[$loc]['auth']['deleteaccount_password_empty']; }
		elseif(strlen($password) > 30) { $this->errormsg[] = $lang[$loc]['auth']['deleteaccount_password_long']; }
		elseif(strlen($password) < 5) { $this->errormsg[] = $lang[$loc]['auth']['deleteaccount_password_short']; }
		
		if(count($this->errormsg) == 0)
		{
			$password = $this->hashpass($password);	
                        
                        
			try{    
                            $this->mysqli->autocommit(False);
                            $query = $this->mysqli->prepare("SELECT password FROM users WHERE username=?");
                            $query->bind_param("s", $username);
                            $query->bind_result($db_password);
                            $query->execute();
                            $query->store_result();
                            $count = $query->num_rows;
                            $query->fetch();
                            $query->close();
                            $this->mysqli->autocommit(True);
                        }catch(Exception $e){
                            $this->mysqli->rollback();
                        }
                                        
                                        
			if($count == 0)
			{
				$this->LogActivity("UNKNOWN", "AUTH_DELETEACCOUNT_FAIL", "Username Incorrect ({$username})");				
				
				$this->errormsg[] = $lang[$loc]['auth']['deleteaccount_username_incorrect'];
				
				return false;
			}
			else 
			{
				if($password == $db_password)
				{
                                        try{    
                                            $this->mysqli->autocommit(False);
                                            $query = $this->mysqli->prepare("DELETE FROM users WHERE username=?");
                                            $query->bind_param("s", $username);
                                            $query->execute();
                                            $query->close();
                                            $this->mysqli->autocommit(True);
                                            echo "Sildim!";
                                        }catch(Exception $e){
                                            $this->mysqli->rollback();
                                        }
                                        
                                        try{    
                                            $this->mysqli->autocommit(False);
                                            $query = $this->mysqli->prepare("DELETE FROM sessions WHERE username=?");
                                            $query->bind_param("s", $username);
                                            $query->execute();
                                            $query->close();
                                            $this->mysqli->autocommit(True);
                                        }catch(Exception $e){
                                            $this->mysqli->rollback();
                                        }
                                        
                                        
					$this->LogActivity($username, "AUTH_DELETEACCOUNT_SUCCESS", "Account deleted - Sessions deleted");					
					
					$this->successmsg[] = $lang[$loc]['auth']['deleteaccount_success'];
					
					return true;
				}
				else 
				{
					$this->LogActivity($username, "AUTH_DELETEACCOUNT_FAIL", "Password incorrect ( DB : {$db_password} / Given : {$password} )");					
					
					$this->errormsg[] = $lang[$loc]['auth']['deleteaccount_password_incorrect'];
			   
					return false;
				}
			}
		}
		else 
		{
			return false;
		}
	}		
	
	/*
	* Adds a new attempt to database based on user's IP
	* @param string $ip
	*/
	
	function addattempt($ip)
	{
		include("config.php");
	
		$query = $this->mysqli->prepare("SELECT count FROM attempts WHERE ip = ?");
		$query->bind_param("s", $ip);
		$query->bind_result($attempt_count);
		$query->execute();
		$query->store_result();
		$count = $query->num_rows;
		$query->fetch();
		$query->close();
		
		if($count == 0)
		{
			// No record of this IP in attempts table already exists, create new
			
			$attempt_expiredate = date("Y-m-d H:i:s", strtotime($auth_conf['security_duration']));
			$attempt_count = 1;
			
			$query = $this->mysqli->prepare("INSERT INTO attempts (ip, count, expiredate) VALUES (?, ?, ?)");
			$query->bind_param("sis", $ip, $attempt_count, $attempt_expiredate);
			$query->execute();
			$query->close();
		}
		else 
		{
			// IP Already exists in attempts table, add 1 to current count
			
			$attempt_expiredate = date("Y-m-d H:i:s", strtotime($auth_conf['security_duration']));
			$attempt_count = $attempt_count + 1;
			
			$query = $this->mysqli->prepare("UPDATE attempts SET count=?, expiredate=? WHERE ip=?");
			$query->bind_param("iss", $attempt_count, $attempt_expiredate, $ip);
			$query->execute();
			$query->close();
		}
	}
	
	/*
	* Provides amount of attempts already in database based on user's IP
	* @param string $ip
	* @return int $attempt_count
	*/
	
	function getattempt($ip)
	{
		$query = $this->mysqli->prepare("SELECT count FROM attempts WHERE ip = ?");
		$query->bind_param("s", $ip);
		$query->bind_result($attempt_count);
		$query->execute();
		$query->store_result();
		$count = $query->num_rows;
		$query->fetch();
		$query->close();
		
		if($count == 0)
		{
			$attempt_count = 0;
		}
		
		return $attempt_count;
	}
	
	/*
	* Function used to remove expired attempt logs from database (Recommended as Cron Job)
	*/
	
	function expireattempt()
	{
		$query = $this->mysqli->prepare("SELECT ip, expiredate FROM attempts");
		$query->bind_result($ip, $expiredate);
		$query->execute();
		$query->store_result();
		$count = $query->num_rows;
		
		$curr_time = strtotime(date("Y-m-d H:i:s"));
		
		if($count != 0)
		{
			while($query->fetch())
			{
				$attempt_expiredate = strtotime($expiredate);
				
				if($attempt_expiredate <= $curr_time)
				{
					$query2 = $this->mysqli->prepare("DELETE FROM attempts WHERE ip = ?");
					$query2->bind_param("s", $ip);
					$query2->execute();
					$query2->close();
				}
			}
		}
	}
	
	/*
	* Logs users actions on the site to database for future viewing
	* @param string $username
	* @param string $action
	* @param string $additionalinfo
	* @return boolean
	*/
	
	function LogActivity($username, $action, $additionalinfo = "none")
	{
		include("config.php");
		include("lang.php");
	
		if(strlen($username) == 0) { $username = "GUEST"; }
		elseif(strlen($username) < 3) { $this->errormsg[] = $lang[$loc]['auth']['logactivity_username_short']; return false; }
		elseif(strlen($username) > 30) { $this->errormsg[] = $lang[$loc]['auth']['logactivity_username_long']; return false; }
		
		if(strlen($action) == 0) { $this->errormsg[] = $lang[$loc]['auth']['logactivity_action_empty']; return false; }
		elseif(strlen($action) < 3) { $this->errormsg[] = $lang[$loc]['auth']['logactivity_action_short']; return false; }
		elseif(strlen($action) > 100) { $this->errormsg[] = $lang[$loc]['auth']['logactivity_action_long']; return false; }
		
		if(strlen($additionalinfo) == 0) { $additionalinfo = "none"; }
		elseif(strlen($additionalinfo) > 500) { $this->errormsg[] = $lang[$loc]['auth']['logactivity_addinfo_long']; return false; }
		
		if(count($this->errormsg) == 0)
		{
			$ip = $_SERVER['REMOTE_ADDR'];
			$date = date("Y-m-d H:i:s");
			
                        try{    
                            $this->mysqli->autocommit(False);
                            $query = $this->mysqli->prepare("INSERT INTO activitylog (date, username, action, additionalinfo, ip) VALUES (?, ?, ?, ?, ?)");
                            $query->bind_param("sssss", $date, $username, $action, $additionalinfo, $ip);
                            $query->execute();
                            $query->close();
                            $this->mysqli->autocommit(True);
                        }catch(Exception $e){
                            $this->mysqli->rollback();
                        }
			
			return true;
		}
	}
	/*
	* Hash user's password with SHA512, base64_encode, ROT13 and salts !
	* @param string $password
	* @return string $password
	*/
	
	function hashpass($password)
	{
		include("config.php");
	
		$password = hash("SHA512", base64_encode(str_rot13(hash("SHA512", str_rot13($auth_conf['salt_1'] . $password . $auth_conf['salt_2'])))));
		return $password;
	}
        
        
        
        
     
        
        
        
        
        
        
        
        function selectActor()
        {
            
            include("config.php");
            include("lang.php");
            
           
            try{    
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("SELECT P.`Person_ID`,P.`Person_Banner`,  P.`Person_Name`, P.`Performor_Famous`, P.`Performer_StartYear` FROM `film_person` P  WHERE P.`Performor_Famous` IS NOT NULL order by P.`Person_Name` asc" );   			
				$query->execute();
				$result = $query->get_result();
				$query->close();
				$this->mysqli->autocommit(True);
				return $result; 
			}catch(Exception $e){
				$this->mysqli->rollback();	
			}
        }
                
         function selectDirector()
        {
            
            include("config.php");
            include("lang.php");
            
           
            try{    
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("SELECT P.`Person_ID`,P.`Person_Banner`,  P.`Person_Name`, P.`Director_Famous`, P.`Director_TotalFilm` FROM `film_person` P  WHERE P.`Director_Famous` IS NOT NULL order by P.`Person_Name` asc" );   			
				$query->execute();
				$result = $query->get_result();
				$query->close();
				$this->mysqli->autocommit(True);
				return $result; 
			}catch(Exception $e){
				$this->mysqli->rollback();	
			}
        }	   
        function getfilmnumber (){
            include("config.php");
           
				try{    
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("SELECT COUNT(*) as NumberofFilms FROM `cinema_films` " );				
				$query->execute();
				$result = $query->get_result();
				$query->close();
				$this->mysqli->autocommit(True);
				return $result; 
			}catch(Exception $e){
				$this->mysqli->rollback();	
			}
		
            
        }
        
        
        function getfilmnumbertype ($typeid){
            include("config.php");
           
				try{    
                                    $typeid = intval($typeid);
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("SELECT COUNT(*) as NumberofFilms FROM cinema_films F JOIN `typing` T NATURAL JOIN film_type where T.Film_ID= F.Film_ID and T.Type_ID=?" );				
				$query->bind_param("i",$typeid);
                                $query->execute();
				$result = $query->get_result();
				$query->close();
				$this->mysqli->autocommit(True);
				return $result; 
			}catch(Exception $e){
				$this->mysqli->rollback();	
			}
		
            
        }
        
        
        function getmaxfilmnumber (){
            include("config.php");
           
				try{    
                                   
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("SELECT MAX(Temp.number) as `MaxNumberofFilms` FROM (select count(T.Film_ID) as number from cinema_films F JOIN `typing` T NATURAL JOIN film_type where T.Film_ID= F.Film_ID group by T.Type_ID ) as Temp" );				
				                        
                           
                                
                              
                                $query->execute();
				$result = $query->get_result();
				$query->close();
				$this->mysqli->autocommit(True);
				return $result; 
			}catch(Exception $e){
				$this->mysqli->rollback();	
			}
		
            
        }
        function getminfilmnumber (){
            include("config.php");
           
				try{    
                                   
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("SELECT MIN(Temp.number) as `MinNumberofFilms` FROM (select count(T.Film_ID) as number from cinema_films F JOIN `typing` T NATURAL JOIN film_type where T.Film_ID= F.Film_ID group by T.Type_ID ) as Temp" );				
				$query->execute();
				$result = $query->get_result();
				$query->close();
				$this->mysqli->autocommit(True);
				return $result; 
			}catch(Exception $e){
				$this->mysqli->rollback();	
			}
		
        }  
          function getminfilmduration() {
           include("config.php");
           
				try{    
                                   
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("SELECT C.`Film_Name`, C.Film_Duration as `min` FROM `cinema_films` C  WHERE C.Film_Duration IN ( SELECT MIN(F.Film_Duration) FROM cinema_films F)" );				
				$query->execute();
				$result = $query->get_result();
				$query->close();
				$this->mysqli->autocommit(True);
				return $result; 
			}catch(Exception $e){
				$this->mysqli->rollback();	
			}           
                        
                        
        }
       
        function getmaxfilmduration() {
           include("config.php");
           
				try{    
                                   
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("SELECT C.`Film_Name`, C.Film_Duration as `max` FROM `cinema_films` C  WHERE C.Film_Duration IN ( SELECT MAX(F.Film_Duration) FROM cinema_films F)" );				
				$query->execute();
				$result = $query->get_result();
				$query->close();
				$this->mysqli->autocommit(True);
				return $result; 
			}catch(Exception $e){
				$this->mysqli->rollback();	
			}           
                        
                        
        }
       
        
        
        function getnumberwoman ($type){
            include("config.php");
           
				try{    
                                    
				$this->mysqli->autocommit(False);
				$query = $this->mysqli->prepare("SELECT COUNT(*) as NumberofWomans FROM film_person T where T.Person_Sex=?" );				
				
                                $query->bind_param("s",$type);
                                $query->execute();
				$result = $query->get_result();
				$query->close();
				$this->mysqli->autocommit(True);
				return $result; 
			}catch(Exception $e){
				$this->mysqli->rollback();	
			}
		
            
        }
}
?>

        
