<!DOCTYPE html>


<?php
    include "auth.class.php";
    $var = new auth();
	
?>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <title> Users - Forum </title>
    <link rel="stylesheet" href="assets/stylesheets/main.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400">
  
<style type="text/css" media="screen">

.tip {
  width: 0px;
  height: 0px;
  
  position: absolute;
  
  background: transparent;
  border: 10px solid #ccc;
}

.tip-right {
  top: 10px;
  right: -25px;
  border-top-color: transparent;
  border-right-color: transparent;
  border-bottom-color: transparent;  
}

.dialogbox .body {
  position: relative; 
  
  max-width: 550px;
  height: auto;
  margin: 20px 10px;
  padding: 5px;
  background: linear-gradient(-90deg,#fff0b3 5%, #cce6ff 100%);
  border-radius: 3px;
  border: 5px solid #a1d3b0;

  
}

.body .message {
  min-height: 40px;
  border-radius: 3px;
  font-family: Arial;
  font-size: 14px;
  font-weight:normal;
  line-height: 1.5;
  color: #003366;
  
}
.td {
  border-collapse:separate;
  border-spacing:10px 10px;
  
}​​​​​​​​​​​​​


    
select {
width:500px;

font: 300 16px/22px "Lato", "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
font-weight:normal;
background:#e6ffe6;
padding:10px;
border:1px solid
}
input[type=radio] {
    vertical-align: text-bottom;
margin-left:15px;
margin-top:10px
    
}
input[type=submit] {
   
padding:10px;
text-align:center;
font-size:18px;
background:linear-gradient(#cce6ff 5%,#fff0b3 100%);
/*border:2px solid #e5a900;*/
color:#001a4d;
font-weight:700;
cursor:pointer;
width:100px;
border-radius:5px
}
input[type=submit]:hover {
  
background:linear-gradient(#fff0b3 5%, #cce6ff 100%);
    color:#001a4d;
}




</style>
</head>
  <body>

    <!-- Header -->

    <header class="primary-header container group">

      <h1 class="logo">
        <a href="index.php">Share US <br> Forum </a>
      </h1>

     <h3 class="tagline" style="font-weight: normal;"> BBM Movie Archive </h3>

      <nav class="nav primary-nav">
        <ul>
          <li><a href="index.php">Home</a></li><!--
          --><li><a href="films.php">Films</a></li><!--
          --><li><a href="schedule.php">Actors/Actrst </a></li><!--
          --><li><a href="venue.php"> Directors</a></li><!--
          --><li><a href="comments.php">Forum</a></li><!--
          -->
<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

    </header>

    <!-- Lead -->

    <section class="row-alt">
      <div class="lead container">

        

        <p>You can see the aspects of movies that we have not seen, the details that are out of sight. Thank you for sharing your thoughts and ideas with us.</p>

        
        </div>   </section>
        
   
            
                
    
                    <center>
                        <form action="comments.php" method="POST">
                            <div><div>
                                    <h6 style="color: #ffffff;font-weight: normal;"> Leave a comment... </h6>
                    <input type="text" name="comment" required style='width:300px'></div>
                    <div><input type="submit" name="submit" value="Post it!"></div> 
			
                        </form></center>
						
		
<?php
   
    if(isset($_POST['submit']))
        {
            $comment= filter_input(INPUT_POST, 'comment', FILTER_SANITIZE_STRING);
            
            
            if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);
                $var->addComment($username, $comment);             
            } else
            {
                $username = 'Guest';
                $var->addComment($username, $comment);              
                
            }
			header("Refresh: 0"); 
            
        }
        
?>				
						
						

      
       
<?php 
                      
           $result = $var->printComment();                   
                while ($row = $result->fetch_assoc()) {
             
               
?>  
        <section class="row">
            <div class="grid">
            <section class="speaker" >
             <div class="col-2-3">  
                <div class="dialogbox">
                    <div class="body">
                      <span class="tip tip-right"></span>
                      <div class="message">
                        <span>
<?php         
                            echo $row['comment'].'<br><br>';
                            echo PHP_EOL;
                            echo '    '.$row['date'].'<br><br>';
            
?>
                        </span></div></div></div>   
            
            
             </div><!--

          --><aside class="col-1-3">
            <div class="speaker-info">
<?php  if( $row['username'] === "Guest" )
            {                          
                
?>
                <img src="assets/images/users/guest.jpg" alt="Guest">
             <ul>
                <li>
                    
<?php

            echo $row['username'];
            
            }else{
                
?>
                     <img src="assets/images/users/users.png" alt="User">
                        <ul>
                <li> 
<?php               
                echo $row['username']; 
               
            }
?>
                </li>
              </ul>
                        </div> 

            
          </aside>

        </section>
    
</div>
    </section>
    
        <?php
        
                }
        ?>
                     
    
                
                
             

                
        
        


    <!-- Footer -->

    <footer class="primary-footer container group">

      <small>&copy; Styles Films </small>

      <nav class="nav">
        <ul>
          <li><a href="index.php">Home</a></li><!--
          --><li><a href="films.php">Films</a></li><!--
          --><li><a href="schedule.php">Actors/Actrst </a></li><!--
          --><li><a href="venue.php"> Directors</a></li><!--
          --><li><a href="comments.php">Forum</a></li>
<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
            <?php      echo $username;  ?>  
              </a></li>
          
<?php          } else
            {      ?>
          <li><a href="register.php">Register</a></li>
<?php          } ?>
        </ul>
      </nav>

    </footer>

  </body>
</html>






