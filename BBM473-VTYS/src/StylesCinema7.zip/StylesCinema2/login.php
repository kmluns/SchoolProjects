<!DOCTYPE html>

<?php
include "auth.class.php";

$var = new auth();

?>

<html lang="en">

  <head>
    <meta charset="utf-8">
    <title>Styles Films </title>
    <link rel="stylesheet" href="assets/stylesheets/main.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400">
  </head>

  <body>

    <!-- Header -->

    <header class="primary-header container group">

      <h1 class="logo">
        <a href="index.php">Styles <br> Films</a>
      </h1>

      <h3 class="tagline"> BBM Movie Archive </h3>

      <nav class="nav primary-nav">
        <ul>
          <li><a href="index.php">Home</a></li><!--
          --><li><a href="films.php"> Films </a></li><!--
          --><li><a href="schedule.php"> Actors/Actrist </a></li><!--
          --><li><a href="venue.php"> Directors </a></li><!--
          -->
<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

    </header>

    <!-- Hero -->

    <section class="hero container">

      <h2> Login Screen  </h2>

     
      
      
      
       <center>

          <div >

      <div >

          <div>

              <img src="assets/images/popcorn.png" alt="Kontrol Paneli" height="150" width="240">

          </div>

          <div >

              <div >
                  
                  <div >

                     

                      <form role="form" name="login" method="POST" action="login.php">

                      <div >

                          <div >


                              <input type="text" name="username" placeholder=" Username " required/>

                          </div>

                      </div>

                      <div >

                          <div >


                              <input type="password" name="userpassword" placeholder=" Password " required/>

                          </div>

                      </div>
                      
                          
                      
                          
                          <button class="btn btn-default btn-alt" role="button"> Login </button>

                          
                      </form>
                      
                     <?php

if ( isset($_POST["username"]) )
    {
        
        $username =filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
        $password= filter_input(INPUT_POST, 'userpassword', FILTER_SANITIZE_STRING);
              
        
        
        if( $var->login($username, $password))
        {
            header("Location: index.php"); /* Redirect browser */
            exit();
        
        }
        else{
            
             foreach ($var->errormsg as $value) {
            echo  " <h6 class=\"text-center\"><font color=\"red\"> " .$value. "</br></font></h6>";
             }
             
        }
        
       
        
    }

?>

                      </div>                 
                
              </div>
            </div>
          </div>

          </div>
          </center>


    </section>

    

    <!-- Footer -->

    <footer class="primary-footer container group">

      <small>&copy; Styles Films</small>

      <nav class="nav">
        <ul>
         <li><a href="index.php">Home</a></li>
          
          <li><a href="films.php"> Films </a></li>
          <li><a href="statistics.php"> Site Statistics </a></li>
	   <li><a href="pages.php">Pages</a></li>
            <li><a href="comments.php">Forum</a></li>
        <?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>  
        </ul>
      </nav>

    </footer>

  </body>
</html>





      