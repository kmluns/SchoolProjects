<!DOCTYPE html>


<?php
    include "auth.class.php";
    $var = new auth();
    
?>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <title> Statistics </title>
    <link rel="stylesheet" href="assets/stylesheets/main.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400">
  
<style type="text/css" media="screen">

select {
width:500px;

font: 300 16px/22px "Lato", "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
font-weight:normal;
background:#e6ffe6;
padding:10px;
border:1px solid
}
input[type=radio] {
    vertical-align: text-bottom;
margin-left:15px;
margin-top:10px
    
}
input[type=submit] {
   
padding:10px;
text-align:center;
font-size:18px;
background:linear-gradient(#cce6ff 5%,#fff0b3 100%);
/*border:2px solid #e5a900;*/
color:#001a4d;
font-weight:700;
cursor:pointer;
width:30%;
border-radius:5px
}
input[type=submit]:hover {
  
background:linear-gradient(#fff0b3 5%, #cce6ff 100%);
    color: #1ab2ff;
}


div {
    background-color: #ffffb3;
    width: 500px;
    border: 25px #aaa;
    padding: 25px;
    margin: 25px auto;
    position:  static;
}

.box{
    font-size: 14px;
}

</style>
</head>
  <body>

    <!-- Header -->

    <header class="primary-header container group">

      <h1 class="logo">
        <a href="index.php">Styles Films <br> Statistics </a>
      </h1>

       <h3 class="tagline" style="font-weight: normal;"> BBM Movie Archive </h3>

      <nav class="nav primary-nav">
        <ul>
          <li><a href="index.php">Home</a></li>
          

        <?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);   
                
    ?>
          <li><a href="user.php"> 
    <?php    echo $username; ?>  
              </a></li>
          
    <?php  } else     { ?>
          <li><a href="register.php">Register</a></li>
    <?php     }    ?>
        </ul>
      </nav>

       
       
       
    </header>
    
    <!-- Lead -->

    <section class="row-alt">
      <div class="lead container">mnfmmfdnmnm</div>  

       
          
          
         
          
                 <div style= padding-bottom:5px > 
                     <h4> Total film number:     <?php  $result = $var->getfilmnumber();   while ( $row = $result->fetch_assoc() ) {echo $row['NumberofFilms'];}  ?> </h4> </div>
      <div>
      <h4>  The number of romantic films: <?php  $result = $var->getfilmnumbertype("1");   while ( $row = $result->fetch_assoc() ) {echo $row['NumberofFilms'];}  ?> </h4> 
      <h4>  The number of adventure films: <?php  $result = $var->getfilmnumbertype("2");   while ( $row = $result->fetch_assoc() ) {echo $row['NumberofFilms'];}  ?> </h4> 
      
      <h4>  The number of comedy films: <?php  $result = $var->getfilmnumbertype("3");   while ( $row = $result->fetch_assoc() ) {echo $row['NumberofFilms'];}  ?> </h4> 
      <h4>  The number of drama films: <?php  $result = $var->getfilmnumbertype("4");   while ( $row = $result->fetch_assoc() ) {echo $row['NumberofFilms'];}  ?> </h4> 
      <h4>  The number of horror films: <?php  $result = $var->getfilmnumbertype("5");   while ( $row = $result->fetch_assoc() ) {echo $row['NumberofFilms'];}  ?> </h4> 
      <h4>  The number of action films: <?php  $result = $var->getfilmnumbertype("6");   while ( $row = $result->fetch_assoc() ) {echo $row['NumberofFilms'];}  ?> </h4> 
      <h4>  The number of animated films: <?php  $result = $var->getfilmnumbertype("7");   while ( $row = $result->fetch_assoc() ) {echo $row['NumberofFilms'];}  ?> </h4> 
      <h4>  The number of science fiction films: <?php  $result = $var->getfilmnumbertype("8");   while ( $row = $result->fetch_assoc() ) {echo $row['NumberofFilms'];}  ?> </h4> 
      <h4>  The number of historical films: <?php  $result = $var->getfilmnumbertype("9");   while ( $row = $result->fetch_assoc() ) {echo $row['NumberofFilms'];}  ?> </h4> 
      <h4>  The number of thriller films: <?php  $result = $var->getfilmnumbertype("10");   while ( $row = $result->fetch_assoc() ) {echo $row['NumberofFilms'];}  ?> </h4> 
      </div>
      
      
      
      <div>
             
      <h4>  The number of historical films: <?php  $result = $var->getmaxfilmnumber();
      while ( $row = $result->fetch_assoc() ) {echo $row['MaxNumberofFilms'];}  ?> </h4> 
      
      
      
      </div>
          
            

        <div>             
      <h4>  The type that has at least the number of movies:  <?php  $result = $var->getminfilmnumber();
      while ( $row = $result->fetch_assoc() ) {echo $row['MinNumberofFilms'];}  ?> </h4>        
      </div>
                
      <div><h4> The shortest film and it's duration: 
      <?php  $result = $var->getminfilmduration();
      while ( $row = $result->fetch_assoc() ) {echo $row['Film_Name']."   ".$row['min'];}  ?>           
      </h4></div>
      
      <div><h4> The longest film it's duration:
      <?php  $result = $var->getmaxfilmduration();
      while ( $row = $result->fetch_assoc() ) {echo $row['Film_Name']."   ".$row['max'];}  ?>           
      </h4></div>
      
     
     
     <div><h4> The number of actrst in the archive:
      <?php  $result = $var->getnumberwoman ("W");
      while ( $row = $result->fetch_assoc() ) {echo $row['NumberofWomans'];}  ?>           
      </h4></div>
     
     <div><h4> The number of actors in the archive:
      <?php  $result = $var->getnumberwoman ("M");
      while ( $row = $result->fetch_assoc() ) {echo $row['NumberofWomans'];}  ?>           
      </h4></div>
      
      
     <div><h4> The oldest film is 
      <?php  $result = $var->getnumberwoman ("M");
      while ( $row = $result->fetch_assoc() ) {echo $row['NumberofWomans'];}  ?>           
      </h4></div>
      
    <div><h4> The newest film is
      <?php  $result = $var->getnumberwoman ("M");
      while ( $row = $result->fetch_assoc() ) {echo $row['NumberofWomans'];}  ?>           
      </h4></div>
      
    </section>
    
      
 


    <!-- Footer -->

    <footer class="primary-footer container group">

      <small>&copy; Styles Films</small>

      <nav class="nav">
        <ul>
          <li><a href="index.php">Home</a></li><!--
          --><li><a href="films.php">Films</a></li><!--
          --><li><a href="schedule.php">Actors/Actrst </a></li><!--
          --><li><a href="venue.php"> Directors</a></li><!--
          --><li><a href="comments.php">Forum</a></li><!--
          -->
<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

    </footer>

  </body>
</html>

<?php
   
    if(isset($_POST['comment']))
        {
            $comment= filter_input(INPUT_POST, 'comment', FILTER_SANITIZE_STRING);
            
            
            if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);
                $var->addComment($username, $comment);             
            } else
            {
                $username = 'Guest';
                $var->addComment($username, $comment);              
                
            }
            
            header("Refresh: 0;");
        }
        
?>
