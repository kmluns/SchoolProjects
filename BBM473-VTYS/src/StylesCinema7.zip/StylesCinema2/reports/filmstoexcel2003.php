<?php

include '../PHPReport.php';
include "../auth.class.php";
   $var = new auth();
   $result = $var->printFilmsAll();
   
   
   while($zRow = $result->fetch_assoc())
    {
        $row = array('Films'=>$zRow['Film_Name'],'Title'=>$zRow['Film_Title'],'Information'=>$zRow['Film_Information'],'Banner'=>$zRow['Film_Banner']);
        $props[] = $row;
    }
   
$R=new PHPReport();
$R->load(array(
            'id'=>'Films',
			'header'=>array(
					'Films'=>'Films Name','Title'=>'Film Title','Information'=>'Film Information','Banner'=>'Film Banner'
				),
			'config'=>array(
					'header'=>array(
						'Films'=>array('width'=>120,'align'=>'center'),
						'Film Title'=>array('width'=>80,'align'=>'center'),
						'Film Information'=>array('width'=>80,'align'=>'center'),
						'Film Banner'=>array('width'=>120,'align'=>'center')
					),
					'data'=>array(
						'Films'=>array('align'=>'left'),
						'Film Title'=>array('align'=>'right'),
						'Film Information'=>array('align'=>'right'),
						'Film Banner'=>array('width'=>120,'align'=>'center')
					)
				),
            'data'=>$props
            )
        );

echo $R->render('excel2003');
exit();