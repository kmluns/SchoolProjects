<!DOCTYPE html>


<?php
    include "auth.class.php";
    $var = new auth();
?>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <title> Users - Forum </title>
    <link rel="stylesheet" href="assets/stylesheets/main.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400">
  
<style type="text/css" media="screen">

.tip {
  width: 0px;
  height: 0px;
  
  position: absolute;
  
  background: transparent;
  border: 10px solid #ccc;
}

.tip-right {
  top: 10px;
  right: -25px;
  border-top-color: transparent;
  border-right-color: transparent;
  border-bottom-color: transparent;  
}

.dialogbox .body {
  position: relative;
  
  
  max-width: 550px;
  height: auto;
  margin: 20px 10px;
  padding: 5px;
  background-color: #DADADA;
  border-radius: 3px;
  border: 5px solid #ccc;
}

.body .message {
  min-height: 40px;
  border-radius: 3px;
  font-family: Arial;
  font-size: 14px;
  line-height: 1.5;
  color: #797979;
}

select {
width:500px;

font: 300 16px/22px "Lato", "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
font-weight:normal;
background:#e6ffe6;
padding:10px;
border:1px solid
}
input[type=radio] {
    vertical-align: text-bottom;
margin-left:15px;
margin-top:10px
    
}
input[type=submit] {
   
padding:10px;
text-align:center;
font-size:18px;
background:linear-gradient(#cce6ff 5%,#fff0b3 100%);
/*border:2px solid #e5a900;*/
color:#001a4d;
font-weight:700;
cursor:pointer;
width:30%;
border-radius:5px
}
input[type=submit]:hover {
  
background:linear-gradient(#fff0b3 5%, #cce6ff 100%);
    color: #1ab2ff;
}







</style>
</head>
  <body>

    <!-- Header -->

    <header class="primary-header container group">

      <h1 class="logo">
        <a href="index.php">Share US <br> Forum </a>
      </h1>

       <h3 class="tagline" style="font-weight: normal;"> BBM Movie Archive </h3>

      <nav class="nav primary-nav">
        <ul>
          <li><a href="index.php">Home</a></li><!--
          --><li><a href="filmtypes/romantic.php">Romantic</a></li><!--
          --><li><a href="filmtypes/adventure.php">Adventure</a></li><!--
          --><li><a href="filmtypes/comedy.php">Comedy</a></li>
             <li><a href="filmtypes/drama.php">Drama</a></li>
             <li><a href="filmtypes/horror.php">Horror</a></li>
             <li><a href="filmtypes/action.php">Action</a></li>
             <li><a href="filmtypes/animated.php">Animated</a></li>
             <li><a href="filmtypes/animated.php">Science Fiction</a></li>
             <li><a href="filmtypes/animated.php">Historical movies</a></li>
             <li><a href="filmtypes/animated.php">Thriller</a></li>

<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

       
       
       
    </header>
    
    <!-- Lead -->

    <section class="row-alt">
      <div class="lead container">

       
          
          
          
          <?php
    
        $filmname=filter_input(INPUT_POST, 'filmname');      
        $filmtime=filter_input(INPUT_POST, 'filmtime');
        $filmtype1=filter_input(INPUT_POST, 'filmtype1');
        $filmtype2=filter_input(INPUT_POST, 'filmtype2');
        $filmtype3=filter_input(INPUT_POST, 'filmtype3');
        $imageinfo=filter_input(INPUT_POST, 'imageinfo');
                      
	?>
          
          
         <div class="lead container">           
                  
			 
			<form action="" method="post" name="formf" enctype="multipart/form-data"> 
 <?php
	
	$result = $var->printFilmsAll();
	
	
	
?>            
                 
   <div style= "padding-bottom:10px;" >
<select name="Films">



<option value="default"> Select a film  </option>

<?php
	
	
	while ($row = $result->fetch_assoc()) {
		echo $row['Film_ID'];
?>


<option value="<?php echo $row['Film_ID'];?>" > <?php echo $row['Film_Name'];?> </option>

<?php	
	}
	
	
?>

</select> </div>
<br/><input type="submit" name="submit" value="Get Selected Film Comments" />

                        </div>
                    </div>
						
						
						</form>
<?php
    if(isset($_POST['submit'])){
		  
        $filmid= filter_input(INPUT_POST, 'Films', FILTER_SANITIZE_STRING);
        
            
            $result2 = $var->printCommentFilms($filmid);
            while ($row = $result2->fetch_assoc()) {
               
?>  
        <section class="row">
            <div class="grid">
            <section class="speaker" >
             <div class="col-2-3">  
                <div class="dialogbox">
                    <div class="body">
                      <span class="tip tip-right"></span>
                      <div class="message">
                        <span>
<?php         
                            echo $row['Comment_Text'].'<br><br>';
                            echo PHP_EOL;
                            echo '    '.$row['date'].'<br><br>';
            
?>
                        </span></div></div></div>   
            
            
             </div>

        </section>
    
</div>
    </section>
    
        <?php
        
                }
        ?>
        
 <?php       
    }
?>                 
            
         
      
      
      </div>
        
          
      
    </section>
    
   

    <!-- Footer -->

    <footer class="primary-footer container group">

      <small>&copy; Styles Films</small>

      <nav class="nav">
        <ul>
          <li><a href="index.php">Home</a></li>
         
          <li><a href="/films.php"> Films </a></li>
          <li><a href="/statistics.php"> Site Statistics </a></li>
	   <li><a href="/pages.php">Pages</a></li>
            <li><a href="/comments.php">Forum</a></li>
<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

    </footer>

  </body>
</html>

