<!DOCTYPE html>


<?php
    include "auth.class.php";
    $var = new auth();
    if( !isset($_COOKIE["auth_session"]) )
    {  
        echo "You did not login!!!";
        header("Location: index.php"); /* Redirect browser */
        exit(); 
    }
	
?>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <title> Users - Forum </title>
    <link rel="stylesheet" href="assets/stylesheets/main.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400">
  
<style type="text/css" media="screen">

.tip {
  width: 0px;
  height: 0px;
  
  position: absolute;
  
  background: transparent;
  border: 10px solid #ccc;
}

.tip-right {
  top: 10px;
  right: -25px;
  border-top-color: transparent;
  border-right-color: transparent;
  border-bottom-color: transparent;  
}

.dialogbox .body {
  position: relative;
  
  
  max-width: 550px;
  height: auto;
  margin: 20px 10px;
  padding: 5px;
  background-color: #DADADA;
  border-radius: 3px;
  border: 5px solid #ccc;
}

.body .message {
  min-height: 40px;
  border-radius: 3px;
  font-family: Arial;
  font-size: 14px;
  line-height: 1.5;
  color: #797979;
}
</style>
</head>
  <body>

    <!-- Header -->

    <header class="primary-header container group">

      <h1 class="logo">
        <a href="index.php">Share US <br> Forum </a>
      </h1>

       <h3 class="tagline" style="font-weight: normal;"> BBM Movie Archive </h3>

      <nav class="nav primary-nav">
        <ul>
          <li><a href="index.php">Home</a></li>
<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

    </header>

    <!-- Lead -->

    <section class="row-alt">
      <div class="lead container">
	  
	  
          <form action="" method="post" name="forma" enctype="multipart/form-data">
		  Person ID : <input type="text" name="personid" required style='width:50px'/>
		  Film ID : <input type="text" name="filmid" required style='width:50px'/>
                        <input type="submit" name="act" value=" Delete Act " /></a>     
                </form>
          <form action="" method="post" name="formb" enctype="multipart/form-data">
		  Username : <input type="text" name="username" required style='width:300px'/>
                        <input type="submit" name="log" value=" Delete Log " /></a>    
                </form>
          
          <form action="" method="post" name="formc" enctype="multipart/form-data">
		  Film Name : <input type="text" name="filmname" required style='width:300px'/>
                        <input type="submit" name="films" value=" Delete Films " /></a>  			   
                </form>
          
		  <form action="" method="post" name="formd" enctype="multipart/form-data">
		  Username : <input type="text" name="username" required style='width:300px'/>
                        <input type="submit" name="comments" value=" Delete Comments " /></a>  			   
                </form>
				
		   <form action="" method="post" name="forme" enctype="multipart/form-data">
		   Person Name : <input type="text" name="personname" required style='width:300px'/>
                        <input type="submit" name="person" value=" Delete Person " /></a>  			   
                </form>
				
			<form action="" method="post" name="formf" enctype="multipart/form-data">
			Person Name : <input type="text" name="personname" required style='width:300px'/>
                        <input type="submit" name="crew" value=" Delete Crew " /></a>  			   
                </form>	
				
		  <form action="" method="post" name="formg" enctype="multipart/form-data">
		  Guest ID : <input type="text" name="guestid" required style='width:50px'/>
                        <input type="submit" name="guest" value=" Delete Guest " /></a>  			   
                </form>
				
		<form action="" method="post" name="formh" enctype="multipart/form-data">
		Make Date : <input type="text" name="makedate" required style='width:100px'/>
                        <input type="submit" name="make" value=" Delete Make Less Than Date " /></a>  			   
                </form>		
				
		 <form action="" method="post" name="formi" enctype="multipart/form-data">
		 Person ID : <input type="text" name="personid" required style='width:50px'/>
		  Film ID : <input type="text" name="filmid" required style='width:50px'/>
                        <input type="submit" name="manage" value=" Delete Manage " /></a>  			   
                </form> 
				
		<form action="" method="post" name="formk" enctype="multipart/form-data">
		Company Name : <input type="text" name="companyname" required style='width:300px'/>
                        <input type="submit" name="company" value=" Delete Company " /></a>  			   
                </form>
							
		<form action="" method="post" name="forml" enctype="multipart/form-data">
		Film Name : <input type="text" name="filmname" required style='width:300px'/>
                <input type="submit" name="rating" value=" Delete Rating " /></a>  			   
        </form> 
		
		
		
		  
		  </div> 
          
          
          
          
<?php
        
		if(isset($_POST['act'])){
			$personid=filter_input(INPUT_POST, 'personid');
			$filmid=filter_input(INPUT_POST, 'filmid');
            $var->deleteAct($personid, $filmid);       			         
		}
		else if(isset($_POST['log'])){
			$username=filter_input(INPUT_POST, 'username');
            $var->deleteLogUsername($username);       			         
		}
		else if(isset($_POST['films'])){
			$filmname=filter_input(INPUT_POST, 'filmname');
            $var->deleteFilmName($filmname);      			         
		}
		else if(isset($_POST['comments'])){
			$username=filter_input(INPUT_POST, 'username');
            $var->deleteCommentUsername($username);       			         
		}
		else if(isset($_POST['person'])){
			$personname=filter_input(INPUT_POST, 'personname');
            $var->deletePersonName($personname);       			         
		}
		else if(isset($_POST['crew'])){
			$personname=filter_input(INPUT_POST, 'personname');
            $var->deletePersonCrewName($personname);       			         
		}
		else if(isset($_POST['guest'])){
			$guestid=filter_input(INPUT_POST, 'guestid');
			$var->deleteGuestID($guestid);       			         
		}
		else if(isset($_POST['make'])){
			$makedate=filter_input(INPUT_POST, 'makedate');
            $var->deleteMakeFromDate($makedate);       			         
		}
		else if(isset($_POST['manage'])){
			$personid=filter_input(INPUT_POST, 'personid');
			$filmid=filter_input(INPUT_POST, 'filmid');
            $var->deleteManageIDs($personid,$filmid);       			         
		}
		else if(isset($_POST['company'])){
			$companyname=filter_input(INPUT_POST, 'companyname');
            $var->deleteCompanyName($companyname);       			         
		}
		else if(isset($_POST['rating'])){
			$filmname=filter_input(INPUT_POST, 'filmname');
            $var->deleteRatingFilm($filmname);       			         
		}
?>
          
          
          
          
          
      </div>
    </section>
    
    
    
                
                
             

                
        
        


    <!-- Footer -->

    <footer class="primary-footer container group">

      <small>&copy; Styles Conference</small>

      <nav class="nav">
        <ul>
            <li><a href="index.php">Home</a></li>
<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

    </footer>

  </body>
</html>

