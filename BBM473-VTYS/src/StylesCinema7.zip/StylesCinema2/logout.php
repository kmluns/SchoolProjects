<?php
    include "auth.class.php";
   $var = new auth();
    if( isset($_COOKIE["auth_session"]) )
    {         
        $Session= $var->deletesession($_COOKIE["auth_session"]);
           
    }
    header("Location: index.php"); /* Redirect browser */
        exit();
    
?>