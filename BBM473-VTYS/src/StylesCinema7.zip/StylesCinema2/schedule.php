<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <title>Schedule - Styles Conference</title>
    <link rel="stylesheet" href="assets/stylesheets/main.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400">
  </head>

  <body>

    <!-- Header -->

    <header class="primary-header container group">

      <h1 class="logo">
        <a href="index.php">Styles <br> Conference</a>
      </h1>

      <h3 class="tagline">August 24&ndash;26th &mdash; Chicago, IL</h3>

      <nav class="nav primary-nav">
        <ul>
          <li><a href="index.php">Home</a></li><!--
          --><li><a href="films.php">Films</a></li><!--
          --><li><a href="schedule.php">Schedule</a></li><!--
          --><li><a href="venue.php">Venue</a></li><!--
          --><li><a href="register.php">Register</a></li>
        </ul>
      </nav>

    </header>

    <!-- Lead -->

    <section class="row-alt">
      <div class="lead container">

        <h1>Schedule</h1>

        <p>The conference opens with amazing workshops and continues with two days of incredible talks and keynotes, all of which are facilitated by industry-leading experts.</p>

      </div>
    </section>

    <!-- Footer -->

    <footer class="primary-footer container group">

      <small>&copy; Styles Conference</small>

      <nav class="nav">
        <ul>
           <li><a href="index.php">Home</a></li><!--
          --><li><a href="films.php">Films</a></li><!--
          --><li><a href="schedule.php">Actors/Actrst </a></li><!--
          --><li><a href="venue.php"> Directors</a></li><!--
          --><li><a href="comments.php">Forum</a></li><!--         
          --><li><a href="register.php">Register</a></li>
        </ul>
      </nav>

    </footer>

  </body>
</html>