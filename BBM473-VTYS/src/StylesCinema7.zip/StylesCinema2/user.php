<!DOCTYPE html>
<?php
          include "auth.class.php";
          $var = new auth();
          if( !isset($_COOKIE["auth_session"]) )
          {
                echo "You did not login!!!";
                header("Location: index.php"); /* Redirect browser */
                exit(); 
          }
?>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <title>Styles Films </title>
    <link rel="stylesheet" href="assets/stylesheets/main.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400">
  </head>

  <body>

    <!-- Header -->

    <header class="primary-header container group">

      <h1 class="logo">
        <a href="index.php">Styles <br> Films</a>
      </h1>

       <h3 class="tagline" style="font-weight: normal;"> BBM Movie Archive </h3>

      <nav class="nav primary-nav">
        <ul>
          <li><a href="index.php">Home</a></li><!--
          --><li><a href="films.php"> Films </a></li><!--
          --><li><a href="schedule.php"> Actors/Actrst </a></li><!--
          --><li><a href="venue.php"> Directors </a></li>
            <li><a href="comments.php">Forum</a></li> 
<?php
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

    </header>

    <!-- Hero -->

    <section class="hero container">
        
      <a class="btn btn-alt" href="changeuserinfo.php"> Change Informations </a> <br></br>
      <a class="btn btn-alt" href="logout.php"> Logout </a>

    </section>

    <!-- Teasers -->

    <section class="row">
      <div class="grid">

        <!-- Speakers -->

        <section class="teaser col-1-3">
          <h5>Films</h5>
          <a href="speakers.php">
            <img src="assets/images/home/intersteller.jpg" alt="Intersteller" width="250" height="300">
            <h3>Unforgettable, Legandary Films</h3>
          </a>
          <p>Joining us from all around the world are over twenty fantastic speakers, here to share their stories.</p>
        </section><!--

        Actors

        --><section class="teaser col-1-3">
          <h5>Actor/Actrist</h5>
          <a href="schedule.php">
            <img src="assets/images/home/Scarlett-Johansson.jpg" alt="Conference Attendees" width="250" height="300">
            <h3>Three Inspiring Days</h3>
          </a>
          <p>Along with the movie summaries and their banners, you can add players and their photos.</p>
        </section><!--

        Comments

        --><section class="teaser col-1-3">
          <h5>Comments</h5>
          <a href="venue.php">
            <img src="assets/images/home/comments.jpg" alt="comments" width="250" height="300">
            <h3> Share a comment! </h3>
          </a>
          <p> Your comments are important to us. Let's discuss movies, banners, content and more together. </p>
        </section>

      </div>
    </section>

    <!-- Footer -->

    <footer class="primary-footer container group">

      <small>&copy; Styles Conference</small>

      <nav class="nav">
        <ul>
           <li><a href="index.php">Home</a></li><!--
          --><li><a href="films.php">Films</a></li><!--
          --><li><a href="schedule.php">Actors/Actrst </a></li><!--
          --><li><a href="venue.php"> Directors</a></li><!--
          --><li><a href="comments.php">Forum</a></li><!--
          
          
<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

    </footer>

  </body>
</html>