<!DOCTYPE html>


<?php
    include "auth.class.php";
    $var = new auth();
    if( !isset($_COOKIE["auth_session"]) )
    {  
        echo "You did not login!!!";
        header("Location: index.php"); /* Redirect browser */
        exit(); 
    }
	
?>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <title> Users - Forum </title>
    <link rel="stylesheet" href="assets/stylesheets/main.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400">
  
<style type="text/css" media="screen">

.tip {
  width: 0px;
  height: 0px;
  
  position: absolute;
  
  background: transparent;
  border: 10px solid #ccc;
}

.tip-right {
  top: 10px;
  right: -25px;
  border-top-color: transparent;
  border-right-color: transparent;
  border-bottom-color: transparent;  
}

.dialogbox .body {
  position: relative;
  
  
  max-width: 550px;
  height: auto;
  margin: 20px 10px;
  padding: 5px;
  background-color: #DADADA;
  border-radius: 3px;
  border: 5px solid #ccc;
}

.body .message {
  min-height: 40px;
  border-radius: 3px;
  font-family: Arial;
  font-size: 14px;
  line-height: 1.5;
  color: #797979;
}
</style>
</head>
  <body>

    <!-- Header -->

    <header class="primary-header container group">

      <h1 class="logo">
        <a href="index.php">Share US <br> Forum </a>
      </h1>

       <h3 class="tagline" style="font-weight: normal;"> BBM Movie Archive </h3>

      <nav class="nav primary-nav">
        <ul>
          <li><a href="index.php">Home</a></li>
<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

    </header>

    <!-- Lead -->

    <section class="row-alt">
      <div class="lead container">

          <form action="" method="post" name="formf" enctype="multipart/form-data">
                        <br>Actor SSN </br><input type="text" name="personssn" placeholder=" Actor SSN" required style='width:300px'/>
			<br>Actor Name </br><input type="text" name="person_name" placeholder=" Actor Name" required style='width:300px'/>
			<br>Sex </br> <input type="radio" name="sex" value="M"/>Male

                                <input type="radio" name="sex" value="W"/>Female
                        <br>Actor Famous </br><input type="text" name="performer_famous" placeholder=" Actor Famous" required style='width:300px'/>
                       <br>Actor Start Year </br><input type="text" name="performer_startyear" placeholder=" Actor Start Year" required style='width:150px'/>
                        <br><input  type="submit" name="send" value=" Save " /> </br>     
                </form>
          
          
          
          
          
          
          
          
<?php
        
		if(isset($_POST['send'])){
                    
                    $personssn=filter_input(INPUT_POST, 'personssn'); 
                    $person_name=filter_input(INPUT_POST, 'person_name');      
                    $sex=filter_input(INPUT_POST, 'sex');
                    $performer_famous=filter_input(INPUT_POST, 'performer_famous');
                    $var->insertPerformer($personssn,$person_name,$sex,$performer_famous,$performer_startyear,$username);				
							
						
						
                
                    
		}
	
?>
          
          
          
          
          
      </div>
    </section>
    
    
    
                
                
             

                
        
        


    <!-- Footer -->

    <footer class="primary-footer container group">

      <small>&copy; Styles Conference</small>

      <nav class="nav">
        <ul>
            <li><a href="index.php">Home</a></li>
<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

    </footer>

  </body>
</html>

