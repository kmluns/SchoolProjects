<!DOCTYPE html>


<?php
    include "auth.class.php";
    $var = new auth();
	
?>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <title> Users - Forum </title>
    <link rel="stylesheet" href="assets/stylesheets/main.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400">
  
<style type="text/css" media="screen">

.tip {
  width: 0px;
  height: 0px;
  
  position: absolute;
  
  background: transparent;
  border: 10px solid #ccc;
}

.tip-right {
  top: 10px;
  right: -25px;
  border-top-color: transparent;
  border-right-color: transparent;
  border-bottom-color: transparent;  
}

.dialogbox .body {
  position: relative;
  
  
  max-width: 550px;
  height: auto;
  margin: 20px 10px;
  padding: 5px;
  background-color: #DADADA;
  border-radius: 3px;
  border: 5px solid #ccc;
}

.body .message {
  min-height: 40px;
  border-radius: 3px;
  font-family: Arial;
  font-size: 14px;
  line-height: 1.5;
  color: #797979;
}
</style>
</head>
  <body>

    <!-- Header -->

    <header class="primary-header container group">

      <h1 class="logo">
        <a href="index.php">Share US <br> Forum </a>
      </h1>

       <h3 class="tagline" style="font-weight: normal;"> BBM Movie Archive </h3>

      <nav class="nav primary-nav">
        <ul>
          <li><a href="index.php">Home</a></li>
<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

    </header>

    <!-- Lead -->

    <section class="row-alt">
      <div class="lead container">

          <form action="changeuserinfo.php" method="post" name="formf" enctype="multipart/form-data">
              <div style= padding-bottom:5px >
                    <label>
                        Old Password
                    </label>
                </div>
            <div style= padding-bottom:5px >  
                        <div style= padding-bottom:5px >
                <input type="password" name="oldpassword" placeholder=" Old Password" required style='width:300px'>
                </div>
            </div>
              
            <div style= padding-bottom:5px >
                <div style= padding-bottom:5px >
                    <label>
                        New Password
                    </label>
                </div>
                        <div style= padding-bottom:5px >
                <input type="password" name="password" placeholder=" New Password"  style='width:300px'>
                </div>
            </div> 
                    <font color="#3D268D"> Please enter between 3 and 30 character </font>
            <div style= padding-bottom:5px >
                <div style= padding-bottom:5px >
                    <label>
                        Verify Password
                    </label>
                </div>
                <div style= padding-bottom:5px >
                    <input type="password" name="verifypassword" placeholder=" New Password"  style='width:300px'>
                </div>
            </div>
            
            
            <div style= padding-bottom:5px >
                <div style= padding-bottom:5px >
                    <label>
                        Email
                    </label>
                </div>
                <div style= padding-bottom:5px >
                    <input type="email" name="email" placeholder=" Email Address" style='width:300px'>
                </div>
            </div>
                    
                    
                <input style="margin-bottom: 15px"  type="submit" name="send" value=" Save " />        
                               
                
              <br/><input  type="submit" name="deleteaccount" value=" Delete Account" /> 
          </form>
          
          
          
          
          
          
          
<?php
		if(isset($_POST['send'])){
                    
					$oldpassword =filter_input(INPUT_POST, 'oldpassword', FILTER_SANITIZE_STRING);
                    $password= filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
                    $verifypassword =filter_input(INPUT_POST, 'verifypassword', FILTER_SANITIZE_STRING);   
					$email= filter_input(INPUT_POST, 'email', FILTER_SANITIZE_STRING);
					
					if ($password != ''){
						
						$var->changepass($username, $oldpassword, $password, $verifypassword);  
						$var->deletesession($_COOKIE["auth_session"]);
						
						if( $email != ''){						
								$var->changeemail($username, $email);
								header("Location: index.php");
								exit();											
						}
						header("Location: index.php");
						exit();
					}                 
                    
                    if( $email != ''){						
							$var->changeemail($username, $email);
							header("Location: index.php");
							exit();							
					
                    }else{
						echo "Something happened on change email and process exit ";
					}
		}
        else if(isset($_POST['deleteaccount'])){
            $oldpassword =filter_input(INPUT_POST, 'oldpassword', FILTER_SANITIZE_STRING);
                    
            $var->deleteaccount($username, $oldpassword);
            $var->deletesession($_COOKIE["auth_session"]);
            header("Location: index.php"); /* Redirect browser */
            exit();
                    
        }
	
?>
          
          
          
          
          
      </div>
    </section>
    
    
    
                
                
             

                
        
        


    <!-- Footer -->

    <footer class="primary-footer container group">

      <small>&copy; Styles Conference</small>

      <nav class="nav">
        <ul>
            <li><a href="index.php">Home</a></li>
        </ul>
      </nav>

    </footer>

  </body>
</html>

