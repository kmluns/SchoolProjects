<!DOCTYPE html>

<?php
include "auth.class.php";

$var = new auth();
          if( isset($_COOKIE["auth_session"]) )
            {      
                echo "You have already logined!!!";
                 header("Location: index.php"); /* Redirect browser */
                 exit();        

          } 
?>


<html lang="en">

  <head>
    <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Register - Styles Films</title>
    <link rel="stylesheet" href="assets/stylesheets/main.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400">
        
        
  </head>

  <body>

    <!-- Header -->

    <header class="primary-header container group">

      <h1 class="logo">
        <a href="index.php">Styles <br> Films</a>
      </h1>

      <h3 class="tagline"> BBM Movie Archive </h3>

      <nav class="nav primary-nav">
        <ul>
          <li><a href="index.php">Home</a></li><!--
          --><li><a href="films.php"> FILMS </a></li><!--
          --><li><a href="schedule.php"> ACTORS/ACTRIST </a></li><!--
          --><li><a href="comments.php">FORUM</a></li><!--
          --><li><a href="register.php"> REGISTER </a></li>
        </ul>
      </nav>

    </header> 
    
    

    <section class="row-alt">
      <div class="lead container">

        <h1>Register</h1>

        <form action="#" method="post">
            <div style= padding-bottom:5px >
                <div style= padding-bottom:5px >
                    <label>
                        Username
                    </label>
                </div>
                <div style= padding-bottom:3px>
                    <input type="text" name="username" placeholder=" Username" required style='width:300px'>
                </div>
                <div >
                    <font color="#53C2FA"> Please enter between 3 and 30 character </font>
                </div>
            </div>
            
            
            <div style= padding-bottom:5px >
                <div style= padding-bottom:5px>
                    <label>
                        Password
                    </label>
                </div>
                <div style= padding-bottom:5px >
                <input type="password" name="password" placeholder=" Password" required style='width:300px'>
                </div>
            </div> 
                    <font color="#3D268D"> Please enter between 3 and 30 character </font>
            <div style= padding-bottom:5px >
                <div style= padding-bottom:5px >
                    <label>
                        Verify Password
                    </label>
                </div>
                <div style= padding-bottom:5px >
                    <input type="password" name="verifypassword" placeholder=" Password" required style='width:300px'>
                </div>
            </div>
            
            
            <div style= padding-bottom:5px >
                <div style= padding-bottom:5px >
                    <label>
                        Email
                    </label>
                </div>
                <div style= padding-bottom:5px >
                    <input type="email" name="email" placeholder=" Email Address" required style='width:300px'>
                </div>
            </div>

            


          <input class="btn btn-default btn-alt" type="submit" name="submit" value=" Sign in ">

        </form>
        
<?php
    if ( isset($_POST["username"]) )
    {
        
        $username =filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
        $password= filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
        $verifypassword =filter_input(INPUT_POST, 'verifypassword', FILTER_SANITIZE_STRING);
        $email= filter_input(INPUT_POST, 'email', FILTER_SANITIZE_STRING);
        
        $var->register($username, $password, $verifypassword, $email);
        $errors =$var->errormsg;
        if($errors){
            foreach ($errors as $value) {
            echo  " <h6 class=\"text-center\"><font color=\"red\"> " .$value. "</br></font></h6>";
            }
        }else{
            header("Location: index.php"); /* Redirect browser */
            exit();
        }
        
        
    }

?>

      </div>
    </section>


    <!-- Footer -->

    <footer class="primary-footer container group">

      <small>&copy; Styles Films</small>

      <nav class="nav">
        <ul>
                
          
          <li><a href="index.php">Home</a></li>
          <li><a href="films.php"> Films </a></li>
          <li><a href="statistics.php"> Site Statistics </a></li>
	   <li><a href="pages.php">Pages</a></li>
            <li><a href="comments.php">Forum</a></li>
        </ul>
      </nav>

    </footer>

  </body>
</html>





