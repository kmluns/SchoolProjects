<!DOCTYPE html>


<?php
    include "auth.class.php";
    $var = new auth();
	
	if( !isset($_COOKIE["auth_session"]) )
    {  
        echo "You did not login!!!";
        header("Location: index.php"); /* Redirect browser */
        exit(); 
    }
	
?>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <title> Users - Forum </title>
    <link rel="stylesheet" href="assets/stylesheets/main.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400">
  
<style type="text/css" media="screen">

.tip {
  width: 0px;
  height: 0px;
  
  position: absolute;
  
  background: transparent;
  border: 10px solid #ccc;
}

.tip-right {
  top: 10px;
  right: -25px;
  border-top-color: transparent;
  border-right-color: transparent;
  border-bottom-color: transparent;  
}

.dialogbox .body {
  position: relative;
  
  
  max-width: 550px;
  height: auto;
  margin: 20px 10px;
  padding: 5px;
  background-color: #DADADA;
  border-radius: 3px;
  border: 5px solid #ccc;
}

.body .message {
  min-height: 40px;
  border-radius: 3px;
  font-family: Arial;
  font-size: 14px;
  line-height: 1.5;
  color: #797979;
}

select {
width:500px;

font: 300 16px/22px "Lato", "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
font-weight:normal;
background:#e6ffe6;
padding:10px;
border:1px solid
}
input[type=radio] {
    vertical-align: text-bottom;
margin-left:15px;
margin-top:10px
    
}
input[type=submit] {
   
padding:10px;
text-align:center;
font-size:18px;
background:linear-gradient(#cce6ff 5%,#fff0b3 100%);
/*border:2px solid #e5a900;*/
color:#001a4d;
font-weight:700;
cursor:pointer;
width:30%;
border-radius:5px
}
input[type=submit]:hover {
  
background:linear-gradient(#fff0b3 5%, #cce6ff 100%);
    color: #1ab2ff;
}







</style>
</head>
  <body>

    <!-- Header -->

    <header class="primary-header container group">

      <h1 class="logo">
        <a href="index.php">Share US <br> Forum </a>
      </h1>

       <h3 class="tagline" style="font-weight: normal;"> BBM Movie Archive </h3>

      <nav class="nav primary-nav">
        <ul>
          <li><a href="index.php">Home</a></li>
             
             

<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

       
       
       
    </header>
    
    <!-- Lead -->

    <section class="row-alt">
      <div class="lead container">

       
          
          
          
          
          
          
         <div class="lead container">           
                         
                 <div style= padding-bottom:5px >

<?php
			$admin = $var->adminControl($username);
            if( $admin){         
	?>				 
             
                     <a href="deleteall.php"><input type="submit" name="submit" value=" Delete All" /></a> 
					<a href="deletespesific.php"><input type="submit" name="submit" value=" Delete Spesific" /></a> 
					<a href="update.php"><input type="submit" name="submit" value=" Update " /></a> 
					
					
					<a href="adddirector.php"><input type="submit" name="submit" value=" Add a Director " /></a> 
					<a href="addcrew.php"><input type="submit" name="submit" value=" Add a Crew " /></a> 
					<a href="addcompany.php"><input type="submit" name="submit" value=" Add a Company " /></a> 
					
					<a href="addperformer.php"><input type="submit" name="submit" value=" Add a Actor " /></a>
					<a href="addcomment.php"><input type="submit" name="submit" value=" Add a Comment on Film " /></a> 
					
					</div>

<?php
			}else{        
	?>
				
					
				
					<a href="adddirector.php"><input type="submit" name="submit" value=" Add a Director " /></a> 
					<a href="addcrew.php"><input type="submit" name="submit" value=" Add a Crew " /></a> 
					<a href="addcompany.php"><input type="submit" name="submit" value=" Add a Company " /></a> 
					
					<a href="addperformer.php"><input type="submit" name="submit" value=" Add a Actor " /></a>
					<a href="addcomment.php"><input type="submit" name="submit" value=" Add a Comment on Film " /></a> 
					
					</div>

<?php
			}       
	?>					 
             
			 
			 
			 
			 
                    </div>                
            
         
      
      
      </div>
        
          
      
    </section>
    
      
  


    <!-- Footer -->

    <footer class="primary-footer container group">

      <small>&copy; Styles Films</small>

      <nav class="nav">
        <ul>
          <li><a href="index.php">Home</a></li>           
          <li><a href="films.php"> Films </a></li>
          <li><a href="statistics.php"> Site Statistics </a></li>
	   <li><a href="pages.php">Pages</a></li>
            <li><a href="comments.php">Forum</a></li>
<?php        
          if( isset($_COOKIE["auth_session"]) )
            {                          
                $Session= $var->sessioninfo($_COOKIE["auth_session"]);
                $username = ($Session["username"]);         
?>
          <li><a href="user.php"> 
<?php      
                  echo $username;
?>  
              </a></li>
          
<?php
          } else
            {
?>
          <li><a href="register.php">Register</a></li>
<?php
            }
?>
        </ul>
      </nav>

    </footer>

  </body>
</html>
